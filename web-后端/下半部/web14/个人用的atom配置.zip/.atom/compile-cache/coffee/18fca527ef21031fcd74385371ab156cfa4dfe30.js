(function() {
  var BufferedProcess, DESCRIPTION, ForkGistIdInputView, GitHubApi, PackageManager, REMOVE_KEYS, SyncSettings, fs, _, _ref,
    __hasProp = {}.hasOwnProperty;

  BufferedProcess = require('atom').BufferedProcess;

  fs = require('fs');

  _ = require('underscore-plus');

  _ref = [], GitHubApi = _ref[0], PackageManager = _ref[1];

  ForkGistIdInputView = null;

  DESCRIPTION = 'Atom configuration storage operated by http://atom.io/packages/sync-settings';

  REMOVE_KEYS = ['sync-settings.gistId', 'sync-settings.personalAccessToken', 'sync-settings._analyticsUserId', 'sync-settings._lastBackupHash'];

  SyncSettings = {
    config: require('./config.coffee'),
    activate: function() {
      return setImmediate((function(_this) {
        return function() {
          var mandatorySettingsApplied;
          if (GitHubApi == null) {
            GitHubApi = require('github');
          }
          if (PackageManager == null) {
            PackageManager = require('./package-manager');
          }
          atom.commands.add('atom-workspace', "sync-settings:backup", function() {
            return _this.backup();
          });
          atom.commands.add('atom-workspace', "sync-settings:restore", function() {
            return _this.restore();
          });
          atom.commands.add('atom-workspace', "sync-settings:view-backup", function() {
            return _this.viewBackup();
          });
          atom.commands.add('atom-workspace', "sync-settings:check-backup", function() {
            return _this.checkForUpdate();
          });
          atom.commands.add('atom-workspace', "sync-settings:fork", function() {
            return _this.inputForkGistId();
          });
          mandatorySettingsApplied = _this.checkMandatorySettings();
          if (atom.config.get('sync-settings.checkForUpdatedBackup') && mandatorySettingsApplied) {
            return _this.checkForUpdate();
          }
        };
      })(this));
    },
    deactivate: function() {
      var _ref1;
      return (_ref1 = this.inputView) != null ? _ref1.destroy() : void 0;
    },
    serialize: function() {},
    getGistId: function() {
      var gistId;
      gistId = atom.config.get('sync-settings.gistId');
      if (gistId) {
        gistId = gistId.trim();
      }
      return gistId;
    },
    getPersonalAccessToken: function() {
      var token;
      token = atom.config.get('sync-settings.personalAccessToken');
      if (token) {
        token = token.trim();
      }
      return token;
    },
    checkMandatorySettings: function() {
      var missingSettings;
      missingSettings = [];
      if (!this.getGistId()) {
        missingSettings.push("Gist ID");
      }
      if (!this.getPersonalAccessToken()) {
        missingSettings.push("GitHub personal access token");
      }
      if (missingSettings.length) {
        this.notifyMissingMandatorySettings(missingSettings);
      }
      return missingSettings.length === 0;
    },
    checkForUpdate: function(cb) {
      if (cb == null) {
        cb = null;
      }
      if (this.getGistId()) {
        console.debug('checking latest backup...');
        return this.createClient().gists.get({
          id: this.getGistId()
        }, (function(_this) {
          return function(err, res) {
            var SyntaxError, message, _ref1, _ref2;
            if (err) {
              console.error("error while retrieving the gist. does it exists?", err);
              try {
                message = JSON.parse(err.message).message;
                if (message === 'Not Found') {
                  message = 'Gist ID Not Found';
                }
              } catch (_error) {
                SyntaxError = _error;
                message = err.message;
              }
              atom.notifications.addError("sync-settings: Error retrieving your settings. (" + message + ")");
              return typeof cb === "function" ? cb() : void 0;
            }
            if ((res != null ? (_ref1 = res.history) != null ? (_ref2 = _ref1[0]) != null ? _ref2.version : void 0 : void 0 : void 0) == null) {
              console.error("could not interpret result:", res);
              atom.notifications.addError("sync-settings: Error retrieving your settings.");
              return typeof cb === "function" ? cb() : void 0;
            }
            console.debug("latest backup version " + res.history[0].version);
            if (res.history[0].version !== atom.config.get('sync-settings._lastBackupHash')) {
              _this.notifyNewerBackup();
            } else if (!atom.config.get('sync-settings.quietUpdateCheck')) {
              _this.notifyBackupUptodate();
            }
            return typeof cb === "function" ? cb() : void 0;
          };
        })(this));
      } else {
        return this.notifyMissingMandatorySettings(["Gist ID"]);
      }
    },
    notifyNewerBackup: function() {
      var notification, workspaceElement;
      workspaceElement = atom.views.getView(atom.workspace);
      return notification = atom.notifications.addWarning("sync-settings: Your settings are out of date.", {
        dismissable: true,
        buttons: [
          {
            text: "Backup",
            onDidClick: function() {
              atom.commands.dispatch(workspaceElement, "sync-settings:backup");
              return notification.dismiss();
            }
          }, {
            text: "View backup",
            onDidClick: function() {
              return atom.commands.dispatch(workspaceElement, "sync-settings:view-backup");
            }
          }, {
            text: "Restore",
            onDidClick: function() {
              atom.commands.dispatch(workspaceElement, "sync-settings:restore");
              return notification.dismiss();
            }
          }, {
            text: "Dismiss",
            onDidClick: function() {
              return notification.dismiss();
            }
          }
        ]
      });
    },
    notifyBackupUptodate: function() {
      return atom.notifications.addSuccess("sync-settings: Latest backup is already applied.");
    },
    notifyMissingMandatorySettings: function(missingSettings) {
      var context, errorMsg, notification;
      context = this;
      errorMsg = "sync-settings: Mandatory settings missing: " + missingSettings.join(', ');
      return notification = atom.notifications.addError(errorMsg, {
        dismissable: true,
        buttons: [
          {
            text: "Package settings",
            onDidClick: function() {
              context.goToPackageSettings();
              return notification.dismiss();
            }
          }
        ]
      });
    },
    backup: function(cb) {
      var cmtend, cmtstart, ext, file, files, _i, _len, _ref1, _ref2, _ref3, _ref4, _ref5, _ref6, _ref7;
      if (cb == null) {
        cb = null;
      }
      files = {};
      if (atom.config.get('sync-settings.syncSettings')) {
        files["settings.json"] = {
          content: this.getFilteredSettings()
        };
      }
      if (atom.config.get('sync-settings.syncPackages')) {
        files["packages.json"] = {
          content: JSON.stringify(this.getPackages(), null, '\t')
        };
      }
      if (atom.config.get('sync-settings.syncKeymap')) {
        files["keymap.cson"] = {
          content: (_ref1 = this.fileContent(atom.keymaps.getUserKeymapPath())) != null ? _ref1 : "# keymap file (not found)"
        };
      }
      if (atom.config.get('sync-settings.syncStyles')) {
        files["styles.less"] = {
          content: (_ref2 = this.fileContent(atom.styles.getUserStyleSheetPath())) != null ? _ref2 : "// styles file (not found)"
        };
      }
      if (atom.config.get('sync-settings.syncInit')) {
        files["init.coffee"] = {
          content: (_ref3 = this.fileContent(atom.config.configDirPath + "/init.coffee")) != null ? _ref3 : "# initialization file (not found)"
        };
      }
      if (atom.config.get('sync-settings.syncSnippets')) {
        files["snippets.cson"] = {
          content: (_ref4 = this.fileContent(atom.config.configDirPath + "/snippets.cson")) != null ? _ref4 : "# snippets file (not found)"
        };
      }
      _ref6 = (_ref5 = atom.config.get('sync-settings.extraFiles')) != null ? _ref5 : [];
      for (_i = 0, _len = _ref6.length; _i < _len; _i++) {
        file = _ref6[_i];
        ext = file.slice(file.lastIndexOf(".")).toLowerCase();
        cmtstart = "#";
        if (ext === ".less" || ext === ".scss" || ext === ".js") {
          cmtstart = "//";
        }
        if (ext === ".css") {
          cmtstart = "/*";
        }
        cmtend = "";
        if (ext === ".css") {
          cmtend = "*/";
        }
        files[file] = {
          content: (_ref7 = this.fileContent(atom.config.configDirPath + ("/" + file))) != null ? _ref7 : "" + cmtstart + " " + file + " (not found) " + cmtend
        };
      }
      return this.createClient().gists.edit({
        id: this.getGistId(),
        description: atom.config.get('sync-settings.gistDescription'),
        files: files
      }, function(err, res) {
        var SyntaxError, message;
        if (err) {
          console.error("error backing up data: " + err.message, err);
          try {
            message = JSON.parse(err.message).message;
            if (message === 'Not Found') {
              message = 'Gist ID Not Found';
            }
          } catch (_error) {
            SyntaxError = _error;
            message = err.message;
          }
          atom.notifications.addError("sync-settings: Error backing up your settings. (" + message + ")");
        } else {
          atom.config.set('sync-settings._lastBackupHash', res.history[0].version);
          atom.notifications.addSuccess("sync-settings: Your settings were successfully backed up. <br/><a href='" + res.html_url + "'>Click here to open your Gist.</a>");
        }
        return typeof cb === "function" ? cb(err, res) : void 0;
      });
    },
    viewBackup: function() {
      var Shell, gistId;
      Shell = require('shell');
      gistId = this.getGistId();
      return Shell.openExternal("https://gist.github.com/" + gistId);
    },
    getPackages: function() {
      var apmInstallSource, i, metadata, name, packages, theme, version, _ref1;
      packages = [];
      _ref1 = this._getAvailablePackageMetadataWithoutDuplicates();
      for (i in _ref1) {
        metadata = _ref1[i];
        name = metadata.name, version = metadata.version, theme = metadata.theme, apmInstallSource = metadata.apmInstallSource;
        packages.push({
          name: name,
          version: version,
          theme: theme,
          apmInstallSource: apmInstallSource
        });
      }
      return _.sortBy(packages, 'name');
    },
    _getAvailablePackageMetadataWithoutDuplicates: function() {
      var i, package_metadata, packages, path, path2metadata, pkg_name, pkg_path, _i, _len, _ref1, _ref2;
      path2metadata = {};
      package_metadata = atom.packages.getAvailablePackageMetadata();
      _ref1 = atom.packages.getAvailablePackagePaths();
      for (i = _i = 0, _len = _ref1.length; _i < _len; i = ++_i) {
        path = _ref1[i];
        path2metadata[fs.realpathSync(path)] = package_metadata[i];
      }
      packages = [];
      _ref2 = atom.packages.getAvailablePackageNames();
      for (i in _ref2) {
        pkg_name = _ref2[i];
        pkg_path = atom.packages.resolvePackagePath(pkg_name);
        if (path2metadata[pkg_path]) {
          packages.push(path2metadata[pkg_path]);
        } else {
          console.error('could not correlate package name, path, and metadata');
        }
      }
      return packages;
    },
    restore: function(cb) {
      if (cb == null) {
        cb = null;
      }
      return this.createClient().gists.get({
        id: this.getGistId()
      }, (function(_this) {
        return function(err, res) {
          var SyntaxError, callbackAsync, file, filename, message, _ref1;
          if (err) {
            console.error("error while retrieving the gist. does it exists?", err);
            try {
              message = JSON.parse(err.message).message;
              if (message === 'Not Found') {
                message = 'Gist ID Not Found';
              }
            } catch (_error) {
              SyntaxError = _error;
              message = err.message;
            }
            atom.notifications.addError("sync-settings: Error retrieving your settings. (" + message + ")");
            return;
          }
          callbackAsync = false;
          _ref1 = res.files;
          for (filename in _ref1) {
            if (!__hasProp.call(_ref1, filename)) continue;
            file = _ref1[filename];
            switch (filename) {
              case 'settings.json':
                if (atom.config.get('sync-settings.syncSettings')) {
                  _this.applySettings('', JSON.parse(file.content));
                }
                break;
              case 'packages.json':
                if (atom.config.get('sync-settings.syncPackages')) {
                  callbackAsync = true;
                  _this.installMissingPackages(JSON.parse(file.content), cb);
                }
                break;
              case 'keymap.cson':
                if (atom.config.get('sync-settings.syncKeymap')) {
                  fs.writeFileSync(atom.keymaps.getUserKeymapPath(), file.content);
                }
                break;
              case 'styles.less':
                if (atom.config.get('sync-settings.syncStyles')) {
                  fs.writeFileSync(atom.styles.getUserStyleSheetPath(), file.content);
                }
                break;
              case 'init.coffee':
                if (atom.config.get('sync-settings.syncInit')) {
                  fs.writeFileSync(atom.config.configDirPath + "/init.coffee", file.content);
                }
                break;
              case 'snippets.cson':
                if (atom.config.get('sync-settings.syncSnippets')) {
                  fs.writeFileSync(atom.config.configDirPath + "/snippets.cson", file.content);
                }
                break;
              default:
                fs.writeFileSync("" + atom.config.configDirPath + "/" + filename, file.content);
            }
          }
          atom.config.set('sync-settings._lastBackupHash', res.history[0].version);
          atom.notifications.addSuccess("sync-settings: Your settings were successfully synchronized.");
          if (!callbackAsync) {
            return typeof cb === "function" ? cb() : void 0;
          }
        };
      })(this));
    },
    createClient: function() {
      var github, token;
      token = this.getPersonalAccessToken();
      console.debug("Creating GitHubApi client with token = " + token);
      github = new GitHubApi({
        version: '3.0.0',
        protocol: 'https'
      });
      github.authenticate({
        type: 'oauth',
        token: token
      });
      return github;
    },
    getFilteredSettings: function() {
      var blacklistedKey, blacklistedKeys, settings, _i, _len, _ref1;
      settings = JSON.parse(JSON.stringify(atom.config.settings));
      blacklistedKeys = REMOVE_KEYS.concat((_ref1 = atom.config.get('sync-settings.blacklistedKeys')) != null ? _ref1 : []);
      for (_i = 0, _len = blacklistedKeys.length; _i < _len; _i++) {
        blacklistedKey = blacklistedKeys[_i];
        blacklistedKey = blacklistedKey.split(".");
        this._removeProperty(settings, blacklistedKey);
      }
      return JSON.stringify(settings, null, '\t');
    },
    _removeProperty: function(obj, key) {
      var currentKey, lastKey;
      lastKey = key.length === 1;
      currentKey = key.shift();
      if (!lastKey && _.isObject(obj[currentKey]) && !_.isArray(obj[currentKey])) {
        return this._removeProperty(obj[currentKey], key);
      } else {
        return delete obj[currentKey];
      }
    },
    goToPackageSettings: function() {
      return atom.workspace.open("atom://config/packages/sync-settings");
    },
    applySettings: function(pref, settings) {
      var colorKeys, isColor, key, keyPath, value, valueKeys, _results;
      _results = [];
      for (key in settings) {
        value = settings[key];
        keyPath = "" + pref + "." + key;
        isColor = false;
        if (_.isObject(value)) {
          valueKeys = Object.keys(value);
          colorKeys = ['alpha', 'blue', 'green', 'red'];
          isColor = _.isEqual(_.sortBy(valueKeys), colorKeys);
        }
        if (_.isObject(value) && !_.isArray(value) && !isColor) {
          _results.push(this.applySettings(keyPath, value));
        } else {
          console.debug("config.set " + keyPath.slice(1) + "=" + value);
          _results.push(atom.config.set(keyPath.slice(1), value));
        }
      }
      return _results;
    },
    installMissingPackages: function(packages, cb) {
      var available_package, available_packages, concurrency, failed, i, installNextPackage, missing_packages, notifications, p, pkg, succeeded, _i, _j, _len, _results;
      available_packages = this.getPackages();
      missing_packages = [];
      for (_i = 0, _len = packages.length; _i < _len; _i++) {
        pkg = packages[_i];
        available_package = (function() {
          var _j, _len1, _results;
          _results = [];
          for (_j = 0, _len1 = available_packages.length; _j < _len1; _j++) {
            p = available_packages[_j];
            if (p.name === pkg.name) {
              _results.push(p);
            }
          }
          return _results;
        })();
        if (available_package.length === 0) {
          missing_packages.push(pkg);
        } else if (!(!!pkg.apmInstallSource === !!available_package[0].apmInstallSource)) {
          missing_packages.push(pkg);
        }
      }
      if (missing_packages.length === 0) {
        atom.notifications.addInfo("Sync-settings: no packages to install");
        return typeof cb === "function" ? cb() : void 0;
      }
      notifications = {};
      succeeded = [];
      failed = [];
      installNextPackage = (function(_this) {
        return function() {
          var count, failedStr, i;
          if (missing_packages.length > 0) {
            pkg = missing_packages.shift();
            i = succeeded.length + failed.length + Object.keys(notifications).length + 1;
            count = i + missing_packages.length;
            notifications[pkg.name] = atom.notifications.addInfo("Sync-settings: installing " + pkg.name + " (" + i + "/" + count + ")", {
              dismissable: true
            });
            return (function(pkg) {
              return _this.installPackage(pkg, function(error) {
                notifications[pkg.name].dismiss();
                delete notifications[pkg.name];
                if (error != null) {
                  failed.push(pkg.name);
                  atom.notifications.addWarning("Sync-settings: failed to install " + pkg.name);
                } else {
                  succeeded.push(pkg.name);
                }
                return installNextPackage();
              });
            })(pkg);
          } else if (Object.keys(notifications).length === 0) {
            if (failed.length === 0) {
              atom.notifications.addSuccess("Sync-settings: finished installing " + succeeded.length + " packages");
            } else {
              failed.sort();
              failedStr = failed.join(', ');
              atom.notifications.addWarning("Sync-settings: finished installing packages (" + failed.length + " failed: " + failedStr + ")", {
                dismissable: true
              });
            }
            return typeof cb === "function" ? cb() : void 0;
          }
        };
      })(this);
      concurrency = Math.min(missing_packages.length, 8);
      _results = [];
      for (i = _j = 0; 0 <= concurrency ? _j < concurrency : _j > concurrency; i = 0 <= concurrency ? ++_j : --_j) {
        _results.push(installNextPackage());
      }
      return _results;
    },
    installPackage: function(pack, cb) {
      var packageManager, type;
      type = pack.theme ? 'theme' : 'package';
      console.info("Installing " + type + " " + pack.name + "...");
      packageManager = new PackageManager();
      return packageManager.install(pack, function(error) {
        var _ref1;
        if (error != null) {
          console.error("Installing " + type + " " + pack.name + " failed", (_ref1 = error.stack) != null ? _ref1 : error, error.stderr);
        } else {
          console.info("Installed " + type + " " + pack.name);
        }
        return typeof cb === "function" ? cb(error) : void 0;
      });
    },
    fileContent: function(filePath) {
      var e;
      try {
        return fs.readFileSync(filePath, {
          encoding: 'utf8'
        }) || null;
      } catch (_error) {
        e = _error;
        console.error("Error reading file " + filePath + ". Probably doesn't exist.", e);
        return null;
      }
    },
    inputForkGistId: function() {
      if (ForkGistIdInputView == null) {
        ForkGistIdInputView = require('./fork-gistid-input-view');
      }
      this.inputView = new ForkGistIdInputView();
      return this.inputView.setCallbackInstance(this);
    },
    forkGistId: function(forkId) {
      return this.createClient().gists.fork({
        id: forkId
      }, (function(_this) {
        return function(err, res) {
          var SyntaxError, message;
          if (err) {
            try {
              message = JSON.parse(err.message).message;
              if (message === "Not Found") {
                message = "Gist ID Not Found";
              }
            } catch (_error) {
              SyntaxError = _error;
              message = err.message;
            }
            atom.notifications.addError("sync-settings: Error forking settings. (" + message + ")");
            return typeof cb === "function" ? cb() : void 0;
          }
          if (res.id) {
            atom.config.set("sync-settings.gistId", res.id);
            atom.notifications.addSuccess("sync-settings: Forked successfully to the new Gist ID " + res.id + " which has been saved to your config.");
          } else {
            atom.notifications.addError("sync-settings: Error forking settings");
          }
          return typeof cb === "function" ? cb() : void 0;
        };
      })(this));
    }
  };

  module.exports = SyncSettings;

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiZmlsZTovLy9DOi9Vc2Vycy9BZG1pbmlzdHJhdG9yLy5hdG9tL3BhY2thZ2VzL3N5bmMtc2V0dGluZ3MvbGliL3N5bmMtc2V0dGluZ3MuY29mZmVlIgogIF0sCiAgIm5hbWVzIjogW10sCiAgIm1hcHBpbmdzIjogIkFBQ0E7QUFBQSxNQUFBLG9IQUFBO0lBQUEsNkJBQUE7O0FBQUEsRUFBQyxrQkFBbUIsT0FBQSxDQUFRLE1BQVIsRUFBbkIsZUFBRCxDQUFBOztBQUFBLEVBQ0EsRUFBQSxHQUFLLE9BQUEsQ0FBUSxJQUFSLENBREwsQ0FBQTs7QUFBQSxFQUVBLENBQUEsR0FBSSxPQUFBLENBQVEsaUJBQVIsQ0FGSixDQUFBOztBQUFBLEVBR0EsT0FBOEIsRUFBOUIsRUFBQyxtQkFBRCxFQUFZLHdCQUhaLENBQUE7O0FBQUEsRUFJQSxtQkFBQSxHQUFzQixJQUp0QixDQUFBOztBQUFBLEVBT0EsV0FBQSxHQUFjLDhFQVBkLENBQUE7O0FBQUEsRUFRQSxXQUFBLEdBQWMsQ0FDWixzQkFEWSxFQUVaLG1DQUZZLEVBR1osZ0NBSFksRUFJWiwrQkFKWSxDQVJkLENBQUE7O0FBQUEsRUFlQSxZQUFBLEdBQ0U7QUFBQSxJQUFBLE1BQUEsRUFBUSxPQUFBLENBQVEsaUJBQVIsQ0FBUjtBQUFBLElBRUEsUUFBQSxFQUFVLFNBQUEsR0FBQTthQUVSLFlBQUEsQ0FBYSxDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQSxHQUFBO0FBRVgsY0FBQSx3QkFBQTs7WUFBQSxZQUFhLE9BQUEsQ0FBUSxRQUFSO1dBQWI7O1lBQ0EsaUJBQWtCLE9BQUEsQ0FBUSxtQkFBUjtXQURsQjtBQUFBLFVBR0EsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFkLENBQWtCLGdCQUFsQixFQUFvQyxzQkFBcEMsRUFBNEQsU0FBQSxHQUFBO21CQUMxRCxLQUFDLENBQUEsTUFBRCxDQUFBLEVBRDBEO1VBQUEsQ0FBNUQsQ0FIQSxDQUFBO0FBQUEsVUFLQSxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQWQsQ0FBa0IsZ0JBQWxCLEVBQW9DLHVCQUFwQyxFQUE2RCxTQUFBLEdBQUE7bUJBQzNELEtBQUMsQ0FBQSxPQUFELENBQUEsRUFEMkQ7VUFBQSxDQUE3RCxDQUxBLENBQUE7QUFBQSxVQU9BLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBZCxDQUFrQixnQkFBbEIsRUFBb0MsMkJBQXBDLEVBQWlFLFNBQUEsR0FBQTttQkFDL0QsS0FBQyxDQUFBLFVBQUQsQ0FBQSxFQUQrRDtVQUFBLENBQWpFLENBUEEsQ0FBQTtBQUFBLFVBU0EsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFkLENBQWtCLGdCQUFsQixFQUFvQyw0QkFBcEMsRUFBa0UsU0FBQSxHQUFBO21CQUNoRSxLQUFDLENBQUEsY0FBRCxDQUFBLEVBRGdFO1VBQUEsQ0FBbEUsQ0FUQSxDQUFBO0FBQUEsVUFXQSxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQWQsQ0FBa0IsZ0JBQWxCLEVBQW9DLG9CQUFwQyxFQUEwRCxTQUFBLEdBQUE7bUJBQ3hELEtBQUMsQ0FBQSxlQUFELENBQUEsRUFEd0Q7VUFBQSxDQUExRCxDQVhBLENBQUE7QUFBQSxVQWNBLHdCQUFBLEdBQTJCLEtBQUMsQ0FBQSxzQkFBRCxDQUFBLENBZDNCLENBQUE7QUFlQSxVQUFBLElBQXFCLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBWixDQUFnQixxQ0FBaEIsQ0FBQSxJQUEyRCx3QkFBaEY7bUJBQUEsS0FBQyxDQUFBLGNBQUQsQ0FBQSxFQUFBO1dBakJXO1FBQUEsRUFBQTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBYixFQUZRO0lBQUEsQ0FGVjtBQUFBLElBdUJBLFVBQUEsRUFBWSxTQUFBLEdBQUE7QUFDVixVQUFBLEtBQUE7cURBQVUsQ0FBRSxPQUFaLENBQUEsV0FEVTtJQUFBLENBdkJaO0FBQUEsSUEwQkEsU0FBQSxFQUFXLFNBQUEsR0FBQSxDQTFCWDtBQUFBLElBNEJBLFNBQUEsRUFBVyxTQUFBLEdBQUE7QUFDVCxVQUFBLE1BQUE7QUFBQSxNQUFBLE1BQUEsR0FBUyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQVosQ0FBZ0Isc0JBQWhCLENBQVQsQ0FBQTtBQUNBLE1BQUEsSUFBRyxNQUFIO0FBQ0UsUUFBQSxNQUFBLEdBQVMsTUFBTSxDQUFDLElBQVAsQ0FBQSxDQUFULENBREY7T0FEQTtBQUdBLGFBQU8sTUFBUCxDQUpTO0lBQUEsQ0E1Qlg7QUFBQSxJQWtDQSxzQkFBQSxFQUF3QixTQUFBLEdBQUE7QUFDdEIsVUFBQSxLQUFBO0FBQUEsTUFBQSxLQUFBLEdBQVEsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFaLENBQWdCLG1DQUFoQixDQUFSLENBQUE7QUFDQSxNQUFBLElBQUcsS0FBSDtBQUNFLFFBQUEsS0FBQSxHQUFRLEtBQUssQ0FBQyxJQUFOLENBQUEsQ0FBUixDQURGO09BREE7QUFHQSxhQUFPLEtBQVAsQ0FKc0I7SUFBQSxDQWxDeEI7QUFBQSxJQXdDQSxzQkFBQSxFQUF3QixTQUFBLEdBQUE7QUFDdEIsVUFBQSxlQUFBO0FBQUEsTUFBQSxlQUFBLEdBQWtCLEVBQWxCLENBQUE7QUFDQSxNQUFBLElBQUcsQ0FBQSxJQUFLLENBQUEsU0FBRCxDQUFBLENBQVA7QUFDRSxRQUFBLGVBQWUsQ0FBQyxJQUFoQixDQUFxQixTQUFyQixDQUFBLENBREY7T0FEQTtBQUdBLE1BQUEsSUFBRyxDQUFBLElBQUssQ0FBQSxzQkFBRCxDQUFBLENBQVA7QUFDRSxRQUFBLGVBQWUsQ0FBQyxJQUFoQixDQUFxQiw4QkFBckIsQ0FBQSxDQURGO09BSEE7QUFLQSxNQUFBLElBQUcsZUFBZSxDQUFDLE1BQW5CO0FBQ0UsUUFBQSxJQUFDLENBQUEsOEJBQUQsQ0FBZ0MsZUFBaEMsQ0FBQSxDQURGO09BTEE7QUFPQSxhQUFPLGVBQWUsQ0FBQyxNQUFoQixLQUEwQixDQUFqQyxDQVJzQjtJQUFBLENBeEN4QjtBQUFBLElBa0RBLGNBQUEsRUFBZ0IsU0FBQyxFQUFELEdBQUE7O1FBQUMsS0FBRztPQUNsQjtBQUFBLE1BQUEsSUFBRyxJQUFDLENBQUEsU0FBRCxDQUFBLENBQUg7QUFDRSxRQUFBLE9BQU8sQ0FBQyxLQUFSLENBQWMsMkJBQWQsQ0FBQSxDQUFBO2VBQ0EsSUFBQyxDQUFBLFlBQUQsQ0FBQSxDQUFlLENBQUMsS0FBSyxDQUFDLEdBQXRCLENBQ0U7QUFBQSxVQUFBLEVBQUEsRUFBSSxJQUFDLENBQUEsU0FBRCxDQUFBLENBQUo7U0FERixFQUVFLENBQUEsU0FBQSxLQUFBLEdBQUE7aUJBQUEsU0FBQyxHQUFELEVBQU0sR0FBTixHQUFBO0FBQ0EsZ0JBQUEsa0NBQUE7QUFBQSxZQUFBLElBQUcsR0FBSDtBQUNFLGNBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyxrREFBZCxFQUFrRSxHQUFsRSxDQUFBLENBQUE7QUFDQTtBQUNFLGdCQUFBLE9BQUEsR0FBVSxJQUFJLENBQUMsS0FBTCxDQUFXLEdBQUcsQ0FBQyxPQUFmLENBQXVCLENBQUMsT0FBbEMsQ0FBQTtBQUNBLGdCQUFBLElBQWlDLE9BQUEsS0FBVyxXQUE1QztBQUFBLGtCQUFBLE9BQUEsR0FBVSxtQkFBVixDQUFBO2lCQUZGO2VBQUEsY0FBQTtBQUlFLGdCQURJLG9CQUNKLENBQUE7QUFBQSxnQkFBQSxPQUFBLEdBQVUsR0FBRyxDQUFDLE9BQWQsQ0FKRjtlQURBO0FBQUEsY0FNQSxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQW5CLENBQTRCLGtEQUFBLEdBQW1ELE9BQW5ELEdBQTJELEdBQXZGLENBTkEsQ0FBQTtBQU9BLGdEQUFPLGFBQVAsQ0FSRjthQUFBO0FBVUEsWUFBQSxJQUFPLDZIQUFQO0FBQ0UsY0FBQSxPQUFPLENBQUMsS0FBUixDQUFjLDZCQUFkLEVBQTZDLEdBQTdDLENBQUEsQ0FBQTtBQUFBLGNBQ0EsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFuQixDQUE0QixnREFBNUIsQ0FEQSxDQUFBO0FBRUEsZ0RBQU8sYUFBUCxDQUhGO2FBVkE7QUFBQSxZQWVBLE9BQU8sQ0FBQyxLQUFSLENBQWUsd0JBQUEsR0FBd0IsR0FBRyxDQUFDLE9BQVEsQ0FBQSxDQUFBLENBQUUsQ0FBQyxPQUF0RCxDQWZBLENBQUE7QUFnQkEsWUFBQSxJQUFHLEdBQUcsQ0FBQyxPQUFRLENBQUEsQ0FBQSxDQUFFLENBQUMsT0FBZixLQUE0QixJQUFJLENBQUMsTUFBTSxDQUFDLEdBQVosQ0FBZ0IsK0JBQWhCLENBQS9CO0FBQ0UsY0FBQSxLQUFDLENBQUEsaUJBQUQsQ0FBQSxDQUFBLENBREY7YUFBQSxNQUVLLElBQUcsQ0FBQSxJQUFRLENBQUMsTUFBTSxDQUFDLEdBQVosQ0FBZ0IsZ0NBQWhCLENBQVA7QUFDSCxjQUFBLEtBQUMsQ0FBQSxvQkFBRCxDQUFBLENBQUEsQ0FERzthQWxCTDs4Q0FxQkEsY0F0QkE7VUFBQSxFQUFBO1FBQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUZGLEVBRkY7T0FBQSxNQUFBO2VBNEJFLElBQUMsQ0FBQSw4QkFBRCxDQUFnQyxDQUFDLFNBQUQsQ0FBaEMsRUE1QkY7T0FEYztJQUFBLENBbERoQjtBQUFBLElBaUZBLGlCQUFBLEVBQW1CLFNBQUEsR0FBQTtBQUVqQixVQUFBLDhCQUFBO0FBQUEsTUFBQSxnQkFBQSxHQUFtQixJQUFJLENBQUMsS0FBSyxDQUFDLE9BQVgsQ0FBbUIsSUFBSSxDQUFDLFNBQXhCLENBQW5CLENBQUE7YUFDQSxZQUFBLEdBQWUsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFuQixDQUE4QiwrQ0FBOUIsRUFDYjtBQUFBLFFBQUEsV0FBQSxFQUFhLElBQWI7QUFBQSxRQUNBLE9BQUEsRUFBUztVQUFDO0FBQUEsWUFDUixJQUFBLEVBQU0sUUFERTtBQUFBLFlBRVIsVUFBQSxFQUFZLFNBQUEsR0FBQTtBQUNWLGNBQUEsSUFBSSxDQUFDLFFBQVEsQ0FBQyxRQUFkLENBQXVCLGdCQUF2QixFQUF5QyxzQkFBekMsQ0FBQSxDQUFBO3FCQUNBLFlBQVksQ0FBQyxPQUFiLENBQUEsRUFGVTtZQUFBLENBRko7V0FBRCxFQUtOO0FBQUEsWUFDRCxJQUFBLEVBQU0sYUFETDtBQUFBLFlBRUQsVUFBQSxFQUFZLFNBQUEsR0FBQTtxQkFDVixJQUFJLENBQUMsUUFBUSxDQUFDLFFBQWQsQ0FBdUIsZ0JBQXZCLEVBQXlDLDJCQUF6QyxFQURVO1lBQUEsQ0FGWDtXQUxNLEVBU047QUFBQSxZQUNELElBQUEsRUFBTSxTQURMO0FBQUEsWUFFRCxVQUFBLEVBQVksU0FBQSxHQUFBO0FBQ1YsY0FBQSxJQUFJLENBQUMsUUFBUSxDQUFDLFFBQWQsQ0FBdUIsZ0JBQXZCLEVBQXlDLHVCQUF6QyxDQUFBLENBQUE7cUJBQ0EsWUFBWSxDQUFDLE9BQWIsQ0FBQSxFQUZVO1lBQUEsQ0FGWDtXQVRNLEVBY047QUFBQSxZQUNELElBQUEsRUFBTSxTQURMO0FBQUEsWUFFRCxVQUFBLEVBQVksU0FBQSxHQUFBO3FCQUFHLFlBQVksQ0FBQyxPQUFiLENBQUEsRUFBSDtZQUFBLENBRlg7V0FkTTtTQURUO09BRGEsRUFIRTtJQUFBLENBakZuQjtBQUFBLElBeUdBLG9CQUFBLEVBQXNCLFNBQUEsR0FBQTthQUNwQixJQUFJLENBQUMsYUFBYSxDQUFDLFVBQW5CLENBQThCLGtEQUE5QixFQURvQjtJQUFBLENBekd0QjtBQUFBLElBNkdBLDhCQUFBLEVBQWdDLFNBQUMsZUFBRCxHQUFBO0FBQzlCLFVBQUEsK0JBQUE7QUFBQSxNQUFBLE9BQUEsR0FBVSxJQUFWLENBQUE7QUFBQSxNQUNBLFFBQUEsR0FBVyw2Q0FBQSxHQUFnRCxlQUFlLENBQUMsSUFBaEIsQ0FBcUIsSUFBckIsQ0FEM0QsQ0FBQTthQUdBLFlBQUEsR0FBZSxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQW5CLENBQTRCLFFBQTVCLEVBQ2I7QUFBQSxRQUFBLFdBQUEsRUFBYSxJQUFiO0FBQUEsUUFDQSxPQUFBLEVBQVM7VUFBQztBQUFBLFlBQ1IsSUFBQSxFQUFNLGtCQURFO0FBQUEsWUFFUixVQUFBLEVBQVksU0FBQSxHQUFBO0FBQ1IsY0FBQSxPQUFPLENBQUMsbUJBQVIsQ0FBQSxDQUFBLENBQUE7cUJBQ0EsWUFBWSxDQUFDLE9BQWIsQ0FBQSxFQUZRO1lBQUEsQ0FGSjtXQUFEO1NBRFQ7T0FEYSxFQUplO0lBQUEsQ0E3R2hDO0FBQUEsSUEwSEEsTUFBQSxFQUFRLFNBQUMsRUFBRCxHQUFBO0FBQ04sVUFBQSw2RkFBQTs7UUFETyxLQUFHO09BQ1Y7QUFBQSxNQUFBLEtBQUEsR0FBUSxFQUFSLENBQUE7QUFDQSxNQUFBLElBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFaLENBQWdCLDRCQUFoQixDQUFIO0FBQ0UsUUFBQSxLQUFNLENBQUEsZUFBQSxDQUFOLEdBQXlCO0FBQUEsVUFBQSxPQUFBLEVBQVMsSUFBQyxDQUFBLG1CQUFELENBQUEsQ0FBVDtTQUF6QixDQURGO09BREE7QUFHQSxNQUFBLElBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFaLENBQWdCLDRCQUFoQixDQUFIO0FBQ0UsUUFBQSxLQUFNLENBQUEsZUFBQSxDQUFOLEdBQXlCO0FBQUEsVUFBQSxPQUFBLEVBQVMsSUFBSSxDQUFDLFNBQUwsQ0FBZSxJQUFDLENBQUEsV0FBRCxDQUFBLENBQWYsRUFBK0IsSUFBL0IsRUFBcUMsSUFBckMsQ0FBVDtTQUF6QixDQURGO09BSEE7QUFLQSxNQUFBLElBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFaLENBQWdCLDBCQUFoQixDQUFIO0FBQ0UsUUFBQSxLQUFNLENBQUEsYUFBQSxDQUFOLEdBQXVCO0FBQUEsVUFBQSxPQUFBLGlGQUEyRCwyQkFBM0Q7U0FBdkIsQ0FERjtPQUxBO0FBT0EsTUFBQSxJQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBWixDQUFnQiwwQkFBaEIsQ0FBSDtBQUNFLFFBQUEsS0FBTSxDQUFBLGFBQUEsQ0FBTixHQUF1QjtBQUFBLFVBQUEsT0FBQSxvRkFBOEQsNEJBQTlEO1NBQXZCLENBREY7T0FQQTtBQVNBLE1BQUEsSUFBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQVosQ0FBZ0Isd0JBQWhCLENBQUg7QUFDRSxRQUFBLEtBQU0sQ0FBQSxhQUFBLENBQU4sR0FBdUI7QUFBQSxVQUFBLE9BQUEsMkZBQXFFLG1DQUFyRTtTQUF2QixDQURGO09BVEE7QUFXQSxNQUFBLElBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFaLENBQWdCLDRCQUFoQixDQUFIO0FBQ0UsUUFBQSxLQUFNLENBQUEsZUFBQSxDQUFOLEdBQXlCO0FBQUEsVUFBQSxPQUFBLDZGQUF1RSw2QkFBdkU7U0FBekIsQ0FERjtPQVhBO0FBY0E7QUFBQSxXQUFBLDRDQUFBO3lCQUFBO0FBQ0UsUUFBQSxHQUFBLEdBQU0sSUFBSSxDQUFDLEtBQUwsQ0FBVyxJQUFJLENBQUMsV0FBTCxDQUFpQixHQUFqQixDQUFYLENBQWlDLENBQUMsV0FBbEMsQ0FBQSxDQUFOLENBQUE7QUFBQSxRQUNBLFFBQUEsR0FBVyxHQURYLENBQUE7QUFFQSxRQUFBLElBQW1CLEdBQUEsS0FBUSxPQUFSLElBQUEsR0FBQSxLQUFpQixPQUFqQixJQUFBLEdBQUEsS0FBMEIsS0FBN0M7QUFBQSxVQUFBLFFBQUEsR0FBVyxJQUFYLENBQUE7U0FGQTtBQUdBLFFBQUEsSUFBbUIsR0FBQSxLQUFRLE1BQTNCO0FBQUEsVUFBQSxRQUFBLEdBQVcsSUFBWCxDQUFBO1NBSEE7QUFBQSxRQUlBLE1BQUEsR0FBUyxFQUpULENBQUE7QUFLQSxRQUFBLElBQWlCLEdBQUEsS0FBUSxNQUF6QjtBQUFBLFVBQUEsTUFBQSxHQUFTLElBQVQsQ0FBQTtTQUxBO0FBQUEsUUFNQSxLQUFNLENBQUEsSUFBQSxDQUFOLEdBQ0U7QUFBQSxVQUFBLE9BQUEseUZBQWlFLEVBQUEsR0FBRyxRQUFILEdBQVksR0FBWixHQUFlLElBQWYsR0FBb0IsZUFBcEIsR0FBbUMsTUFBcEc7U0FQRixDQURGO0FBQUEsT0FkQTthQXdCQSxJQUFDLENBQUEsWUFBRCxDQUFBLENBQWUsQ0FBQyxLQUFLLENBQUMsSUFBdEIsQ0FDRTtBQUFBLFFBQUEsRUFBQSxFQUFJLElBQUMsQ0FBQSxTQUFELENBQUEsQ0FBSjtBQUFBLFFBQ0EsV0FBQSxFQUFhLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBWixDQUFnQiwrQkFBaEIsQ0FEYjtBQUFBLFFBRUEsS0FBQSxFQUFPLEtBRlA7T0FERixFQUlFLFNBQUMsR0FBRCxFQUFNLEdBQU4sR0FBQTtBQUNBLFlBQUEsb0JBQUE7QUFBQSxRQUFBLElBQUcsR0FBSDtBQUNFLFVBQUEsT0FBTyxDQUFDLEtBQVIsQ0FBYyx5QkFBQSxHQUEwQixHQUFHLENBQUMsT0FBNUMsRUFBcUQsR0FBckQsQ0FBQSxDQUFBO0FBQ0E7QUFDRSxZQUFBLE9BQUEsR0FBVSxJQUFJLENBQUMsS0FBTCxDQUFXLEdBQUcsQ0FBQyxPQUFmLENBQXVCLENBQUMsT0FBbEMsQ0FBQTtBQUNBLFlBQUEsSUFBaUMsT0FBQSxLQUFXLFdBQTVDO0FBQUEsY0FBQSxPQUFBLEdBQVUsbUJBQVYsQ0FBQTthQUZGO1dBQUEsY0FBQTtBQUlFLFlBREksb0JBQ0osQ0FBQTtBQUFBLFlBQUEsT0FBQSxHQUFVLEdBQUcsQ0FBQyxPQUFkLENBSkY7V0FEQTtBQUFBLFVBTUEsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFuQixDQUE0QixrREFBQSxHQUFtRCxPQUFuRCxHQUEyRCxHQUF2RixDQU5BLENBREY7U0FBQSxNQUFBO0FBU0UsVUFBQSxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQVosQ0FBZ0IsK0JBQWhCLEVBQWlELEdBQUcsQ0FBQyxPQUFRLENBQUEsQ0FBQSxDQUFFLENBQUMsT0FBaEUsQ0FBQSxDQUFBO0FBQUEsVUFDQSxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQW5CLENBQThCLDBFQUFBLEdBQTJFLEdBQUcsQ0FBQyxRQUEvRSxHQUF3RixxQ0FBdEgsQ0FEQSxDQVRGO1NBQUE7MENBV0EsR0FBSSxLQUFLLGNBWlQ7TUFBQSxDQUpGLEVBekJNO0lBQUEsQ0ExSFI7QUFBQSxJQXFLQSxVQUFBLEVBQVksU0FBQSxHQUFBO0FBQ1YsVUFBQSxhQUFBO0FBQUEsTUFBQSxLQUFBLEdBQVEsT0FBQSxDQUFRLE9BQVIsQ0FBUixDQUFBO0FBQUEsTUFDQSxNQUFBLEdBQVMsSUFBQyxDQUFBLFNBQUQsQ0FBQSxDQURULENBQUE7YUFFQSxLQUFLLENBQUMsWUFBTixDQUFvQiwwQkFBQSxHQUEwQixNQUE5QyxFQUhVO0lBQUEsQ0FyS1o7QUFBQSxJQTBLQSxXQUFBLEVBQWEsU0FBQSxHQUFBO0FBQ1gsVUFBQSxvRUFBQTtBQUFBLE1BQUEsUUFBQSxHQUFXLEVBQVgsQ0FBQTtBQUNBO0FBQUEsV0FBQSxVQUFBOzRCQUFBO0FBQ0UsUUFBQyxnQkFBQSxJQUFELEVBQU8sbUJBQUEsT0FBUCxFQUFnQixpQkFBQSxLQUFoQixFQUF1Qiw0QkFBQSxnQkFBdkIsQ0FBQTtBQUFBLFFBQ0EsUUFBUSxDQUFDLElBQVQsQ0FBYztBQUFBLFVBQUMsTUFBQSxJQUFEO0FBQUEsVUFBTyxTQUFBLE9BQVA7QUFBQSxVQUFnQixPQUFBLEtBQWhCO0FBQUEsVUFBdUIsa0JBQUEsZ0JBQXZCO1NBQWQsQ0FEQSxDQURGO0FBQUEsT0FEQTthQUlBLENBQUMsQ0FBQyxNQUFGLENBQVMsUUFBVCxFQUFtQixNQUFuQixFQUxXO0lBQUEsQ0ExS2I7QUFBQSxJQWlMQSw2Q0FBQSxFQUErQyxTQUFBLEdBQUE7QUFDN0MsVUFBQSw4RkFBQTtBQUFBLE1BQUEsYUFBQSxHQUFnQixFQUFoQixDQUFBO0FBQUEsTUFDQSxnQkFBQSxHQUFtQixJQUFJLENBQUMsUUFBUSxDQUFDLDJCQUFkLENBQUEsQ0FEbkIsQ0FBQTtBQUVBO0FBQUEsV0FBQSxvREFBQTt3QkFBQTtBQUNFLFFBQUEsYUFBYyxDQUFBLEVBQUUsQ0FBQyxZQUFILENBQWdCLElBQWhCLENBQUEsQ0FBZCxHQUF1QyxnQkFBaUIsQ0FBQSxDQUFBLENBQXhELENBREY7QUFBQSxPQUZBO0FBQUEsTUFLQSxRQUFBLEdBQVcsRUFMWCxDQUFBO0FBTUE7QUFBQSxXQUFBLFVBQUE7NEJBQUE7QUFDRSxRQUFBLFFBQUEsR0FBVyxJQUFJLENBQUMsUUFBUSxDQUFDLGtCQUFkLENBQWlDLFFBQWpDLENBQVgsQ0FBQTtBQUNBLFFBQUEsSUFBRyxhQUFjLENBQUEsUUFBQSxDQUFqQjtBQUNFLFVBQUEsUUFBUSxDQUFDLElBQVQsQ0FBYyxhQUFjLENBQUEsUUFBQSxDQUE1QixDQUFBLENBREY7U0FBQSxNQUFBO0FBR0UsVUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLHNEQUFkLENBQUEsQ0FIRjtTQUZGO0FBQUEsT0FOQTthQVlBLFNBYjZDO0lBQUEsQ0FqTC9DO0FBQUEsSUFnTUEsT0FBQSxFQUFTLFNBQUMsRUFBRCxHQUFBOztRQUFDLEtBQUc7T0FDWDthQUFBLElBQUMsQ0FBQSxZQUFELENBQUEsQ0FBZSxDQUFDLEtBQUssQ0FBQyxHQUF0QixDQUNFO0FBQUEsUUFBQSxFQUFBLEVBQUksSUFBQyxDQUFBLFNBQUQsQ0FBQSxDQUFKO09BREYsRUFFRSxDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQyxHQUFELEVBQU0sR0FBTixHQUFBO0FBQ0EsY0FBQSwwREFBQTtBQUFBLFVBQUEsSUFBRyxHQUFIO0FBQ0UsWUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLGtEQUFkLEVBQWtFLEdBQWxFLENBQUEsQ0FBQTtBQUNBO0FBQ0UsY0FBQSxPQUFBLEdBQVUsSUFBSSxDQUFDLEtBQUwsQ0FBVyxHQUFHLENBQUMsT0FBZixDQUF1QixDQUFDLE9BQWxDLENBQUE7QUFDQSxjQUFBLElBQWlDLE9BQUEsS0FBVyxXQUE1QztBQUFBLGdCQUFBLE9BQUEsR0FBVSxtQkFBVixDQUFBO2VBRkY7YUFBQSxjQUFBO0FBSUUsY0FESSxvQkFDSixDQUFBO0FBQUEsY0FBQSxPQUFBLEdBQVUsR0FBRyxDQUFDLE9BQWQsQ0FKRjthQURBO0FBQUEsWUFNQSxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQW5CLENBQTRCLGtEQUFBLEdBQW1ELE9BQW5ELEdBQTJELEdBQXZGLENBTkEsQ0FBQTtBQU9BLGtCQUFBLENBUkY7V0FBQTtBQUFBLFVBVUEsYUFBQSxHQUFnQixLQVZoQixDQUFBO0FBWUE7QUFBQSxlQUFBLGlCQUFBOzttQ0FBQTtBQUNFLG9CQUFPLFFBQVA7QUFBQSxtQkFDTyxlQURQO0FBRUksZ0JBQUEsSUFBK0MsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFaLENBQWdCLDRCQUFoQixDQUEvQztBQUFBLGtCQUFBLEtBQUMsQ0FBQSxhQUFELENBQWUsRUFBZixFQUFtQixJQUFJLENBQUMsS0FBTCxDQUFXLElBQUksQ0FBQyxPQUFoQixDQUFuQixDQUFBLENBQUE7aUJBRko7QUFDTztBQURQLG1CQUlPLGVBSlA7QUFLSSxnQkFBQSxJQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBWixDQUFnQiw0QkFBaEIsQ0FBSDtBQUNFLGtCQUFBLGFBQUEsR0FBZ0IsSUFBaEIsQ0FBQTtBQUFBLGtCQUNBLEtBQUMsQ0FBQSxzQkFBRCxDQUF3QixJQUFJLENBQUMsS0FBTCxDQUFXLElBQUksQ0FBQyxPQUFoQixDQUF4QixFQUFrRCxFQUFsRCxDQURBLENBREY7aUJBTEo7QUFJTztBQUpQLG1CQVNPLGFBVFA7QUFVSSxnQkFBQSxJQUFtRSxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQVosQ0FBZ0IsMEJBQWhCLENBQW5FO0FBQUEsa0JBQUEsRUFBRSxDQUFDLGFBQUgsQ0FBaUIsSUFBSSxDQUFDLE9BQU8sQ0FBQyxpQkFBYixDQUFBLENBQWpCLEVBQW1ELElBQUksQ0FBQyxPQUF4RCxDQUFBLENBQUE7aUJBVko7QUFTTztBQVRQLG1CQVlPLGFBWlA7QUFhSSxnQkFBQSxJQUFzRSxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQVosQ0FBZ0IsMEJBQWhCLENBQXRFO0FBQUEsa0JBQUEsRUFBRSxDQUFDLGFBQUgsQ0FBaUIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxxQkFBWixDQUFBLENBQWpCLEVBQXNELElBQUksQ0FBQyxPQUEzRCxDQUFBLENBQUE7aUJBYko7QUFZTztBQVpQLG1CQWVPLGFBZlA7QUFnQkksZ0JBQUEsSUFBNkUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFaLENBQWdCLHdCQUFoQixDQUE3RTtBQUFBLGtCQUFBLEVBQUUsQ0FBQyxhQUFILENBQWlCLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBWixHQUE0QixjQUE3QyxFQUE2RCxJQUFJLENBQUMsT0FBbEUsQ0FBQSxDQUFBO2lCQWhCSjtBQWVPO0FBZlAsbUJBa0JPLGVBbEJQO0FBbUJJLGdCQUFBLElBQStFLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBWixDQUFnQiw0QkFBaEIsQ0FBL0U7QUFBQSxrQkFBQSxFQUFFLENBQUMsYUFBSCxDQUFpQixJQUFJLENBQUMsTUFBTSxDQUFDLGFBQVosR0FBNEIsZ0JBQTdDLEVBQStELElBQUksQ0FBQyxPQUFwRSxDQUFBLENBQUE7aUJBbkJKO0FBa0JPO0FBbEJQO0FBcUJPLGdCQUFBLEVBQUUsQ0FBQyxhQUFILENBQWlCLEVBQUEsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLGFBQWYsR0FBNkIsR0FBN0IsR0FBZ0MsUUFBakQsRUFBNkQsSUFBSSxDQUFDLE9BQWxFLENBQUEsQ0FyQlA7QUFBQSxhQURGO0FBQUEsV0FaQTtBQUFBLFVBb0NBLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBWixDQUFnQiwrQkFBaEIsRUFBaUQsR0FBRyxDQUFDLE9BQVEsQ0FBQSxDQUFBLENBQUUsQ0FBQyxPQUFoRSxDQXBDQSxDQUFBO0FBQUEsVUFzQ0EsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFuQixDQUE4Qiw4REFBOUIsQ0F0Q0EsQ0FBQTtBQXdDQSxVQUFBLElBQUEsQ0FBQSxhQUFBOzhDQUFBLGNBQUE7V0F6Q0E7UUFBQSxFQUFBO01BQUEsQ0FBQSxDQUFBLENBQUEsSUFBQSxDQUZGLEVBRE87SUFBQSxDQWhNVDtBQUFBLElBOE9BLFlBQUEsRUFBYyxTQUFBLEdBQUE7QUFDWixVQUFBLGFBQUE7QUFBQSxNQUFBLEtBQUEsR0FBUSxJQUFDLENBQUEsc0JBQUQsQ0FBQSxDQUFSLENBQUE7QUFBQSxNQUNBLE9BQU8sQ0FBQyxLQUFSLENBQWUseUNBQUEsR0FBeUMsS0FBeEQsQ0FEQSxDQUFBO0FBQUEsTUFFQSxNQUFBLEdBQWEsSUFBQSxTQUFBLENBQ1g7QUFBQSxRQUFBLE9BQUEsRUFBUyxPQUFUO0FBQUEsUUFFQSxRQUFBLEVBQVUsT0FGVjtPQURXLENBRmIsQ0FBQTtBQUFBLE1BTUEsTUFBTSxDQUFDLFlBQVAsQ0FDRTtBQUFBLFFBQUEsSUFBQSxFQUFNLE9BQU47QUFBQSxRQUNBLEtBQUEsRUFBTyxLQURQO09BREYsQ0FOQSxDQUFBO2FBU0EsT0FWWTtJQUFBLENBOU9kO0FBQUEsSUEwUEEsbUJBQUEsRUFBcUIsU0FBQSxHQUFBO0FBRW5CLFVBQUEsMERBQUE7QUFBQSxNQUFBLFFBQUEsR0FBVyxJQUFJLENBQUMsS0FBTCxDQUFXLElBQUksQ0FBQyxTQUFMLENBQWUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxRQUEzQixDQUFYLENBQVgsQ0FBQTtBQUFBLE1BQ0EsZUFBQSxHQUFrQixXQUFXLENBQUMsTUFBWiw4RUFBc0UsRUFBdEUsQ0FEbEIsQ0FBQTtBQUVBLFdBQUEsc0RBQUE7NkNBQUE7QUFDRSxRQUFBLGNBQUEsR0FBaUIsY0FBYyxDQUFDLEtBQWYsQ0FBcUIsR0FBckIsQ0FBakIsQ0FBQTtBQUFBLFFBQ0EsSUFBQyxDQUFBLGVBQUQsQ0FBaUIsUUFBakIsRUFBMkIsY0FBM0IsQ0FEQSxDQURGO0FBQUEsT0FGQTtBQUtBLGFBQU8sSUFBSSxDQUFDLFNBQUwsQ0FBZSxRQUFmLEVBQXlCLElBQXpCLEVBQStCLElBQS9CLENBQVAsQ0FQbUI7SUFBQSxDQTFQckI7QUFBQSxJQW1RQSxlQUFBLEVBQWlCLFNBQUMsR0FBRCxFQUFNLEdBQU4sR0FBQTtBQUNmLFVBQUEsbUJBQUE7QUFBQSxNQUFBLE9BQUEsR0FBVSxHQUFHLENBQUMsTUFBSixLQUFjLENBQXhCLENBQUE7QUFBQSxNQUNBLFVBQUEsR0FBYSxHQUFHLENBQUMsS0FBSixDQUFBLENBRGIsQ0FBQTtBQUdBLE1BQUEsSUFBRyxDQUFBLE9BQUEsSUFBZ0IsQ0FBQyxDQUFDLFFBQUYsQ0FBVyxHQUFJLENBQUEsVUFBQSxDQUFmLENBQWhCLElBQWdELENBQUEsQ0FBSyxDQUFDLE9BQUYsQ0FBVSxHQUFJLENBQUEsVUFBQSxDQUFkLENBQXZEO2VBQ0UsSUFBQyxDQUFBLGVBQUQsQ0FBaUIsR0FBSSxDQUFBLFVBQUEsQ0FBckIsRUFBa0MsR0FBbEMsRUFERjtPQUFBLE1BQUE7ZUFHRSxNQUFBLENBQUEsR0FBVyxDQUFBLFVBQUEsRUFIYjtPQUplO0lBQUEsQ0FuUWpCO0FBQUEsSUE0UUEsbUJBQUEsRUFBcUIsU0FBQSxHQUFBO2FBQ25CLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBZixDQUFvQixzQ0FBcEIsRUFEbUI7SUFBQSxDQTVRckI7QUFBQSxJQStRQSxhQUFBLEVBQWUsU0FBQyxJQUFELEVBQU8sUUFBUCxHQUFBO0FBQ2IsVUFBQSw0REFBQTtBQUFBO1dBQUEsZUFBQTs4QkFBQTtBQUNFLFFBQUEsT0FBQSxHQUFVLEVBQUEsR0FBRyxJQUFILEdBQVEsR0FBUixHQUFXLEdBQXJCLENBQUE7QUFBQSxRQUNBLE9BQUEsR0FBVSxLQURWLENBQUE7QUFFQSxRQUFBLElBQUcsQ0FBQyxDQUFDLFFBQUYsQ0FBVyxLQUFYLENBQUg7QUFDRSxVQUFBLFNBQUEsR0FBWSxNQUFNLENBQUMsSUFBUCxDQUFZLEtBQVosQ0FBWixDQUFBO0FBQUEsVUFDQSxTQUFBLEdBQVksQ0FBQyxPQUFELEVBQVUsTUFBVixFQUFrQixPQUFsQixFQUEyQixLQUEzQixDQURaLENBQUE7QUFBQSxVQUVBLE9BQUEsR0FBVSxDQUFDLENBQUMsT0FBRixDQUFVLENBQUMsQ0FBQyxNQUFGLENBQVMsU0FBVCxDQUFWLEVBQStCLFNBQS9CLENBRlYsQ0FERjtTQUZBO0FBTUEsUUFBQSxJQUFHLENBQUMsQ0FBQyxRQUFGLENBQVcsS0FBWCxDQUFBLElBQXNCLENBQUEsQ0FBSyxDQUFDLE9BQUYsQ0FBVSxLQUFWLENBQTFCLElBQStDLENBQUEsT0FBbEQ7d0JBQ0UsSUFBQyxDQUFBLGFBQUQsQ0FBZSxPQUFmLEVBQXdCLEtBQXhCLEdBREY7U0FBQSxNQUFBO0FBR0UsVUFBQSxPQUFPLENBQUMsS0FBUixDQUFlLGFBQUEsR0FBYSxPQUFRLFNBQXJCLEdBQTJCLEdBQTNCLEdBQThCLEtBQTdDLENBQUEsQ0FBQTtBQUFBLHdCQUNBLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBWixDQUFnQixPQUFRLFNBQXhCLEVBQStCLEtBQS9CLEVBREEsQ0FIRjtTQVBGO0FBQUE7c0JBRGE7SUFBQSxDQS9RZjtBQUFBLElBNlJBLHNCQUFBLEVBQXdCLFNBQUMsUUFBRCxFQUFXLEVBQVgsR0FBQTtBQUN0QixVQUFBLDZKQUFBO0FBQUEsTUFBQSxrQkFBQSxHQUFxQixJQUFDLENBQUEsV0FBRCxDQUFBLENBQXJCLENBQUE7QUFBQSxNQUNBLGdCQUFBLEdBQW1CLEVBRG5CLENBQUE7QUFFQSxXQUFBLCtDQUFBOzJCQUFBO0FBQ0UsUUFBQSxpQkFBQTs7QUFBcUI7ZUFBQSwyREFBQTt1Q0FBQTtnQkFBbUMsQ0FBQyxDQUFDLElBQUYsS0FBVSxHQUFHLENBQUM7QUFBakQsNEJBQUEsRUFBQTthQUFBO0FBQUE7O1lBQXJCLENBQUE7QUFDQSxRQUFBLElBQUcsaUJBQWlCLENBQUMsTUFBbEIsS0FBNEIsQ0FBL0I7QUFFRSxVQUFBLGdCQUFnQixDQUFDLElBQWpCLENBQXNCLEdBQXRCLENBQUEsQ0FGRjtTQUFBLE1BR0ssSUFBRyxDQUFBLENBQUksQ0FBQSxDQUFDLEdBQUksQ0FBQyxnQkFBTixLQUEwQixDQUFBLENBQUMsaUJBQW1CLENBQUEsQ0FBQSxDQUFFLENBQUMsZ0JBQWxELENBQU47QUFFSCxVQUFBLGdCQUFnQixDQUFDLElBQWpCLENBQXNCLEdBQXRCLENBQUEsQ0FGRztTQUxQO0FBQUEsT0FGQTtBQVVBLE1BQUEsSUFBRyxnQkFBZ0IsQ0FBQyxNQUFqQixLQUEyQixDQUE5QjtBQUNFLFFBQUEsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFuQixDQUEyQix1Q0FBM0IsQ0FBQSxDQUFBO0FBQ0EsMENBQU8sYUFBUCxDQUZGO09BVkE7QUFBQSxNQWNBLGFBQUEsR0FBZ0IsRUFkaEIsQ0FBQTtBQUFBLE1BZUEsU0FBQSxHQUFZLEVBZlosQ0FBQTtBQUFBLE1BZ0JBLE1BQUEsR0FBUyxFQWhCVCxDQUFBO0FBQUEsTUFpQkEsa0JBQUEsR0FBcUIsQ0FBQSxTQUFBLEtBQUEsR0FBQTtlQUFBLFNBQUEsR0FBQTtBQUNuQixjQUFBLG1CQUFBO0FBQUEsVUFBQSxJQUFHLGdCQUFnQixDQUFDLE1BQWpCLEdBQTBCLENBQTdCO0FBRUUsWUFBQSxHQUFBLEdBQU0sZ0JBQWdCLENBQUMsS0FBakIsQ0FBQSxDQUFOLENBQUE7QUFBQSxZQUNBLENBQUEsR0FBSSxTQUFTLENBQUMsTUFBVixHQUFtQixNQUFNLENBQUMsTUFBMUIsR0FBbUMsTUFBTSxDQUFDLElBQVAsQ0FBWSxhQUFaLENBQTBCLENBQUMsTUFBOUQsR0FBdUUsQ0FEM0UsQ0FBQTtBQUFBLFlBRUEsS0FBQSxHQUFRLENBQUEsR0FBSSxnQkFBZ0IsQ0FBQyxNQUY3QixDQUFBO0FBQUEsWUFHQSxhQUFjLENBQUEsR0FBRyxDQUFDLElBQUosQ0FBZCxHQUEwQixJQUFJLENBQUMsYUFBYSxDQUFDLE9BQW5CLENBQTRCLDRCQUFBLEdBQTRCLEdBQUcsQ0FBQyxJQUFoQyxHQUFxQyxJQUFyQyxHQUF5QyxDQUF6QyxHQUEyQyxHQUEzQyxHQUE4QyxLQUE5QyxHQUFvRCxHQUFoRixFQUFvRjtBQUFBLGNBQUMsV0FBQSxFQUFhLElBQWQ7YUFBcEYsQ0FIMUIsQ0FBQTttQkFJRyxDQUFBLFNBQUMsR0FBRCxHQUFBO3FCQUNELEtBQUMsQ0FBQSxjQUFELENBQWdCLEdBQWhCLEVBQXFCLFNBQUMsS0FBRCxHQUFBO0FBRW5CLGdCQUFBLGFBQWMsQ0FBQSxHQUFHLENBQUMsSUFBSixDQUFTLENBQUMsT0FBeEIsQ0FBQSxDQUFBLENBQUE7QUFBQSxnQkFDQSxNQUFBLENBQUEsYUFBcUIsQ0FBQSxHQUFHLENBQUMsSUFBSixDQURyQixDQUFBO0FBRUEsZ0JBQUEsSUFBRyxhQUFIO0FBQ0Usa0JBQUEsTUFBTSxDQUFDLElBQVAsQ0FBWSxHQUFHLENBQUMsSUFBaEIsQ0FBQSxDQUFBO0FBQUEsa0JBQ0EsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFuQixDQUErQixtQ0FBQSxHQUFtQyxHQUFHLENBQUMsSUFBdEUsQ0FEQSxDQURGO2lCQUFBLE1BQUE7QUFJRSxrQkFBQSxTQUFTLENBQUMsSUFBVixDQUFlLEdBQUcsQ0FBQyxJQUFuQixDQUFBLENBSkY7aUJBRkE7dUJBUUEsa0JBQUEsQ0FBQSxFQVZtQjtjQUFBLENBQXJCLEVBREM7WUFBQSxDQUFBLENBQUgsQ0FBSSxHQUFKLEVBTkY7V0FBQSxNQWtCSyxJQUFHLE1BQU0sQ0FBQyxJQUFQLENBQVksYUFBWixDQUEwQixDQUFDLE1BQTNCLEtBQXFDLENBQXhDO0FBRUgsWUFBQSxJQUFHLE1BQU0sQ0FBQyxNQUFQLEtBQWlCLENBQXBCO0FBQ0UsY0FBQSxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQW5CLENBQStCLHFDQUFBLEdBQXFDLFNBQVMsQ0FBQyxNQUEvQyxHQUFzRCxXQUFyRixDQUFBLENBREY7YUFBQSxNQUFBO0FBR0UsY0FBQSxNQUFNLENBQUMsSUFBUCxDQUFBLENBQUEsQ0FBQTtBQUFBLGNBQ0EsU0FBQSxHQUFZLE1BQU0sQ0FBQyxJQUFQLENBQVksSUFBWixDQURaLENBQUE7QUFBQSxjQUVBLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBbkIsQ0FBK0IsK0NBQUEsR0FBK0MsTUFBTSxDQUFDLE1BQXRELEdBQTZELFdBQTdELEdBQXdFLFNBQXhFLEdBQWtGLEdBQWpILEVBQXFIO0FBQUEsZ0JBQUMsV0FBQSxFQUFhLElBQWQ7ZUFBckgsQ0FGQSxDQUhGO2FBQUE7OENBTUEsY0FSRztXQW5CYztRQUFBLEVBQUE7TUFBQSxDQUFBLENBQUEsQ0FBQSxJQUFBLENBakJyQixDQUFBO0FBQUEsTUE4Q0EsV0FBQSxHQUFjLElBQUksQ0FBQyxHQUFMLENBQVMsZ0JBQWdCLENBQUMsTUFBMUIsRUFBa0MsQ0FBbEMsQ0E5Q2QsQ0FBQTtBQStDQTtXQUFTLHNHQUFULEdBQUE7QUFDRSxzQkFBQSxrQkFBQSxDQUFBLEVBQUEsQ0FERjtBQUFBO3NCQWhEc0I7SUFBQSxDQTdSeEI7QUFBQSxJQWdWQSxjQUFBLEVBQWdCLFNBQUMsSUFBRCxFQUFPLEVBQVAsR0FBQTtBQUNkLFVBQUEsb0JBQUE7QUFBQSxNQUFBLElBQUEsR0FBVSxJQUFJLENBQUMsS0FBUixHQUFtQixPQUFuQixHQUFnQyxTQUF2QyxDQUFBO0FBQUEsTUFDQSxPQUFPLENBQUMsSUFBUixDQUFjLGFBQUEsR0FBYSxJQUFiLEdBQWtCLEdBQWxCLEdBQXFCLElBQUksQ0FBQyxJQUExQixHQUErQixLQUE3QyxDQURBLENBQUE7QUFBQSxNQUVBLGNBQUEsR0FBcUIsSUFBQSxjQUFBLENBQUEsQ0FGckIsQ0FBQTthQUdBLGNBQWMsQ0FBQyxPQUFmLENBQXVCLElBQXZCLEVBQTZCLFNBQUMsS0FBRCxHQUFBO0FBQzNCLFlBQUEsS0FBQTtBQUFBLFFBQUEsSUFBRyxhQUFIO0FBQ0UsVUFBQSxPQUFPLENBQUMsS0FBUixDQUFlLGFBQUEsR0FBYSxJQUFiLEdBQWtCLEdBQWxCLEdBQXFCLElBQUksQ0FBQyxJQUExQixHQUErQixTQUE5QywwQ0FBc0UsS0FBdEUsRUFBNkUsS0FBSyxDQUFDLE1BQW5GLENBQUEsQ0FERjtTQUFBLE1BQUE7QUFHRSxVQUFBLE9BQU8sQ0FBQyxJQUFSLENBQWMsWUFBQSxHQUFZLElBQVosR0FBaUIsR0FBakIsR0FBb0IsSUFBSSxDQUFDLElBQXZDLENBQUEsQ0FIRjtTQUFBOzBDQUlBLEdBQUksZ0JBTHVCO01BQUEsQ0FBN0IsRUFKYztJQUFBLENBaFZoQjtBQUFBLElBMlZBLFdBQUEsRUFBYSxTQUFDLFFBQUQsR0FBQTtBQUNYLFVBQUEsQ0FBQTtBQUFBO0FBQ0UsZUFBTyxFQUFFLENBQUMsWUFBSCxDQUFnQixRQUFoQixFQUEwQjtBQUFBLFVBQUMsUUFBQSxFQUFVLE1BQVg7U0FBMUIsQ0FBQSxJQUFpRCxJQUF4RCxDQURGO09BQUEsY0FBQTtBQUdFLFFBREksVUFDSixDQUFBO0FBQUEsUUFBQSxPQUFPLENBQUMsS0FBUixDQUFlLHFCQUFBLEdBQXFCLFFBQXJCLEdBQThCLDJCQUE3QyxFQUF5RSxDQUF6RSxDQUFBLENBQUE7ZUFDQSxLQUpGO09BRFc7SUFBQSxDQTNWYjtBQUFBLElBa1dBLGVBQUEsRUFBaUIsU0FBQSxHQUFBOztRQUNmLHNCQUF1QixPQUFBLENBQVEsMEJBQVI7T0FBdkI7QUFBQSxNQUNBLElBQUMsQ0FBQSxTQUFELEdBQWlCLElBQUEsbUJBQUEsQ0FBQSxDQURqQixDQUFBO2FBRUEsSUFBQyxDQUFBLFNBQVMsQ0FBQyxtQkFBWCxDQUErQixJQUEvQixFQUhlO0lBQUEsQ0FsV2pCO0FBQUEsSUF1V0EsVUFBQSxFQUFZLFNBQUMsTUFBRCxHQUFBO2FBQ1YsSUFBQyxDQUFBLFlBQUQsQ0FBQSxDQUFlLENBQUMsS0FBSyxDQUFDLElBQXRCLENBQ0U7QUFBQSxRQUFBLEVBQUEsRUFBSSxNQUFKO09BREYsRUFFRSxDQUFBLFNBQUEsS0FBQSxHQUFBO2VBQUEsU0FBQyxHQUFELEVBQU0sR0FBTixHQUFBO0FBQ0EsY0FBQSxvQkFBQTtBQUFBLFVBQUEsSUFBRyxHQUFIO0FBQ0U7QUFDRSxjQUFBLE9BQUEsR0FBVSxJQUFJLENBQUMsS0FBTCxDQUFXLEdBQUcsQ0FBQyxPQUFmLENBQXVCLENBQUMsT0FBbEMsQ0FBQTtBQUNBLGNBQUEsSUFBaUMsT0FBQSxLQUFXLFdBQTVDO0FBQUEsZ0JBQUEsT0FBQSxHQUFVLG1CQUFWLENBQUE7ZUFGRjthQUFBLGNBQUE7QUFJRSxjQURJLG9CQUNKLENBQUE7QUFBQSxjQUFBLE9BQUEsR0FBVSxHQUFHLENBQUMsT0FBZCxDQUpGO2FBQUE7QUFBQSxZQUtBLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBbkIsQ0FBNEIsMENBQUEsR0FBMkMsT0FBM0MsR0FBbUQsR0FBL0UsQ0FMQSxDQUFBO0FBTUEsOENBQU8sYUFBUCxDQVBGO1dBQUE7QUFTQSxVQUFBLElBQUcsR0FBRyxDQUFDLEVBQVA7QUFDRSxZQUFBLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBWixDQUFnQixzQkFBaEIsRUFBd0MsR0FBRyxDQUFDLEVBQTVDLENBQUEsQ0FBQTtBQUFBLFlBQ0EsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFuQixDQUE4Qix3REFBQSxHQUEyRCxHQUFHLENBQUMsRUFBL0QsR0FBb0UsdUNBQWxHLENBREEsQ0FERjtXQUFBLE1BQUE7QUFJRSxZQUFBLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBbkIsQ0FBNEIsdUNBQTVCLENBQUEsQ0FKRjtXQVRBOzRDQWVBLGNBaEJBO1FBQUEsRUFBQTtNQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FGRixFQURVO0lBQUEsQ0F2V1o7R0FoQkYsQ0FBQTs7QUFBQSxFQTRZQSxNQUFNLENBQUMsT0FBUCxHQUFpQixZQTVZakIsQ0FBQTtBQUFBIgp9

//# sourceURL=/C:/Users/Administrator/.atom/packages/sync-settings/lib/sync-settings.coffee
