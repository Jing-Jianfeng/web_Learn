(function() {
  var ChineseSetting,
    __bind = function(fn, me){ return function(){ return fn.apply(me, arguments); }; };

  ChineseSetting = (function() {
    function ChineseSetting() {
      this.delay = __bind(this.delay, this);
      var CSON;
      CSON = require('cson');
      this.M = CSON.load(__dirname + '/../def/menu_' + process.platform + '.cson');
      this.C = CSON.load(__dirname + '/../def/context.cson');
    }

    ChineseSetting.prototype.activate = function(state) {
      return setTimeout(this.delay, 0);
    };

    ChineseSetting.prototype.delay = function() {
      var config;
      config = atom.config.get('simplified-chinese-menu');
      if (config.useMenu) {
        this.updateMenu(atom.menu.template, this.M.Menu);
        atom.menu.update();
      }
      if (config.useContext) {
        this.updateContextMenu();
      }
      if (config.useSetting) {
        this.updateSettings();
        return atom.workspace.onDidChangeActivePaneItem((function(_this) {
          return function(item) {
            var chineseStatus, settingsTab;
            if (item && item.uri && item.uri.indexOf('atom://config') !== -1) {
              settingsTab = document.querySelector('.tab-bar [data-type="SettingsView"]');
              chineseStatus = settingsTab.getAttribute('inChinese');
              if (chineseStatus !== 'true') {
                settingsTab.setAttribute('inChinese', 'true');
                return _this.updateSettings(true);
              }
            }
          };
        })(this));
      }
    };

    ChineseSetting.prototype.updateMenu = function(menuList, def) {
      var key, menu, set, _i, _len, _results;
      if (!def) {
        return;
      }
      _results = [];
      for (_i = 0, _len = menuList.length; _i < _len; _i++) {
        menu = menuList[_i];
        if (!menu.label) {
          continue;
        }
        key = menu.label;
        if (key.indexOf('…' !== -1)) {
          key = key.replace('…', '...');
        }
        set = def[key];
        if (!set) {
          continue;
        }
        if (key === 'VERSION') {
          if (set != null) {
            menu.label = set.value + ' ' + atom.appVersion;
          }
        } else {
          if (set != null) {
            menu.label = set.value;
          }
        }
        if (menu.submenu != null) {
          _results.push(this.updateMenu(menu.submenu, set.submenu));
        } else {
          _results.push(void 0);
        }
      }
      return _results;
    };

    ChineseSetting.prototype.updateContextMenu = function() {
      var item, itemSet, label, set, _i, _len, _ref, _results;
      console.log('执行 updateContextMenu');
      _ref = atom.contextMenu.itemSets;
      _results = [];
      for (_i = 0, _len = _ref.length; _i < _len; _i++) {
        itemSet = _ref[_i];
        set = this.C.Context[itemSet.selector];
        if (!set) {
          continue;
        }
        _results.push((function() {
          var _j, _len1, _ref1, _results1;
          _ref1 = itemSet.items;
          _results1 = [];
          for (_j = 0, _len1 = _ref1.length; _j < _len1; _j++) {
            item = _ref1[_j];
            if (item.type === "separator") {
              continue;
            }
            label = set[item.command];
            if (label != null) {
              _results1.push(item.label = label);
            } else {
              _results1.push(void 0);
            }
          }
          return _results1;
        })());
      }
      return _results;
    };

    ChineseSetting.prototype.updateSettings = function(onSettingsOpen) {
      if (onSettingsOpen == null) {
        onSettingsOpen = false;
      }
      return setTimeout(this.delaySettings, 0, onSettingsOpen);
    };

    ChineseSetting.prototype.delaySettings = function(onSettingsOpen) {
      var settings;
      settings = require('./../tools/settings');
      return settings.init();
    };

    ChineseSetting.prototype.config = {
      useMenu: {
        title: '汉化菜单',
        description: '如果你不希望汉化`菜单`部分可以关闭此处,设置后可能需要重启 Atom。',
        type: 'boolean',
        "default": true
      },
      useSetting: {
        title: '汉化设置',
        description: '如果你不希望汉化`设置`部分可以关闭此处,设置后可能需要重启 Atom。',
        type: 'boolean',
        "default": true
      },
      useContext: {
        title: '汉化右键菜单',
        description: '如果你不希望汉化`右键菜单`部分可以关闭此处,设置后可能需要重启 Atom。',
        type: 'boolean',
        "default": true
      }
    };

    return ChineseSetting;

  })();

  module.exports = new ChineseSetting();

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiZmlsZTovLy9DOi9Vc2Vycy9BZG1pbmlzdHJhdG9yLy5hdG9tL3BhY2thZ2VzL3NpbXBsaWZpZWQtY2hpbmVzZS1tZW51L2xpYi9tYWluLmNvZmZlZSIKICBdLAogICJuYW1lcyI6IFtdLAogICJtYXBwaW5ncyI6ICJBQUFBO0FBQUEsTUFBQSxjQUFBO0lBQUEsa0ZBQUE7O0FBQUEsRUFBTTtBQUVTLElBQUEsd0JBQUEsR0FBQTtBQUNYLDJDQUFBLENBQUE7QUFBQSxVQUFBLElBQUE7QUFBQSxNQUFBLElBQUEsR0FBTyxPQUFBLENBQVEsTUFBUixDQUFQLENBQUE7QUFBQSxNQUVBLElBQUMsQ0FBQSxDQUFELEdBQUssSUFBSSxDQUFDLElBQUwsQ0FBVSxTQUFBLEdBQVksZUFBWixHQUE0QixPQUFPLENBQUMsUUFBcEMsR0FBNkMsT0FBdkQsQ0FGTCxDQUFBO0FBQUEsTUFJQSxJQUFDLENBQUEsQ0FBRCxHQUFLLElBQUksQ0FBQyxJQUFMLENBQVUsU0FBQSxHQUFZLHNCQUF0QixDQUpMLENBRFc7SUFBQSxDQUFiOztBQUFBLDZCQVFBLFFBQUEsR0FBVSxTQUFDLEtBQUQsR0FBQTthQUNSLFVBQUEsQ0FBVyxJQUFDLENBQUEsS0FBWixFQUFrQixDQUFsQixFQURRO0lBQUEsQ0FSVixDQUFBOztBQUFBLDZCQVdBLEtBQUEsR0FBTyxTQUFBLEdBQUE7QUFDTCxVQUFBLE1BQUE7QUFBQSxNQUFBLE1BQUEsR0FBUyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQVosQ0FBZ0IseUJBQWhCLENBQVQsQ0FBQTtBQUVBLE1BQUEsSUFBRyxNQUFNLENBQUMsT0FBVjtBQUVFLFFBQUEsSUFBQyxDQUFBLFVBQUQsQ0FBWSxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQXRCLEVBQWdDLElBQUMsQ0FBQSxDQUFDLENBQUMsSUFBbkMsQ0FBQSxDQUFBO0FBQUEsUUFDQSxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQVYsQ0FBQSxDQURBLENBRkY7T0FGQTtBQU9BLE1BQUEsSUFBRyxNQUFNLENBQUMsVUFBVjtBQUVFLFFBQUEsSUFBQyxDQUFBLGlCQUFELENBQUEsQ0FBQSxDQUZGO09BUEE7QUFXQSxNQUFBLElBQUcsTUFBTSxDQUFDLFVBQVY7QUFFRSxRQUFBLElBQUMsQ0FBQSxjQUFELENBQUEsQ0FBQSxDQUFBO2VBRUEsSUFBSSxDQUFDLFNBQVMsQ0FBQyx5QkFBZixDQUF5QyxDQUFBLFNBQUEsS0FBQSxHQUFBO2lCQUFBLFNBQUMsSUFBRCxHQUFBO0FBQ3ZDLGdCQUFBLDBCQUFBO0FBQUEsWUFBQSxJQUFHLElBQUEsSUFBUyxJQUFJLENBQUMsR0FBZCxJQUFzQixJQUFJLENBQUMsR0FBRyxDQUFDLE9BQVQsQ0FBaUIsZUFBakIsQ0FBQSxLQUF1QyxDQUFBLENBQWhFO0FBQ0UsY0FBQSxXQUFBLEdBQWMsUUFBUSxDQUFDLGFBQVQsQ0FBdUIscUNBQXZCLENBQWQsQ0FBQTtBQUFBLGNBQ0EsYUFBQSxHQUFnQixXQUFXLENBQUMsWUFBWixDQUF5QixXQUF6QixDQURoQixDQUFBO0FBRUEsY0FBQSxJQUFHLGFBQUEsS0FBbUIsTUFBdEI7QUFDRSxnQkFBQSxXQUFXLENBQUMsWUFBWixDQUF5QixXQUF6QixFQUFxQyxNQUFyQyxDQUFBLENBQUE7dUJBQ0EsS0FBQyxDQUFBLGNBQUQsQ0FBZ0IsSUFBaEIsRUFGRjtlQUhGO2FBRHVDO1VBQUEsRUFBQTtRQUFBLENBQUEsQ0FBQSxDQUFBLElBQUEsQ0FBekMsRUFKRjtPQVpLO0lBQUEsQ0FYUCxDQUFBOztBQUFBLDZCQW1DQSxVQUFBLEdBQWEsU0FBQyxRQUFELEVBQVcsR0FBWCxHQUFBO0FBQ1gsVUFBQSxrQ0FBQTtBQUFBLE1BQUEsSUFBVSxDQUFBLEdBQVY7QUFBQSxjQUFBLENBQUE7T0FBQTtBQUNBO1dBQUEsK0NBQUE7NEJBQUE7QUFDRSxRQUFBLElBQVksQ0FBQSxJQUFRLENBQUMsS0FBckI7QUFBQSxtQkFBQTtTQUFBO0FBQUEsUUFDQSxHQUFBLEdBQU0sSUFBSSxDQUFDLEtBRFgsQ0FBQTtBQUVBLFFBQUEsSUFBRyxHQUFHLENBQUMsT0FBSixDQUFZLEdBQUEsS0FBUyxDQUFBLENBQXJCLENBQUg7QUFDRSxVQUFBLEdBQUEsR0FBTSxHQUFHLENBQUMsT0FBSixDQUFZLEdBQVosRUFBZ0IsS0FBaEIsQ0FBTixDQURGO1NBRkE7QUFBQSxRQUlBLEdBQUEsR0FBTSxHQUFJLENBQUEsR0FBQSxDQUpWLENBQUE7QUFLQSxRQUFBLElBQVksQ0FBQSxHQUFaO0FBQUEsbUJBQUE7U0FMQTtBQU1BLFFBQUEsSUFBRyxHQUFBLEtBQU8sU0FBVjtBQUNFLFVBQUEsSUFBOEMsV0FBOUM7QUFBQSxZQUFBLElBQUksQ0FBQyxLQUFMLEdBQWEsR0FBRyxDQUFDLEtBQUosR0FBVSxHQUFWLEdBQWMsSUFBSSxDQUFDLFVBQWhDLENBQUE7V0FERjtTQUFBLE1BQUE7QUFHRSxVQUFBLElBQTBCLFdBQTFCO0FBQUEsWUFBQSxJQUFJLENBQUMsS0FBTCxHQUFhLEdBQUcsQ0FBQyxLQUFqQixDQUFBO1dBSEY7U0FOQTtBQVVBLFFBQUEsSUFBRyxvQkFBSDt3QkFDRSxJQUFDLENBQUEsVUFBRCxDQUFZLElBQUksQ0FBQyxPQUFqQixFQUEwQixHQUFHLENBQUMsT0FBOUIsR0FERjtTQUFBLE1BQUE7Z0NBQUE7U0FYRjtBQUFBO3NCQUZXO0lBQUEsQ0FuQ2IsQ0FBQTs7QUFBQSw2QkFtREEsaUJBQUEsR0FBbUIsU0FBQSxHQUFBO0FBQ2pCLFVBQUEsbURBQUE7QUFBQSxNQUFBLE9BQU8sQ0FBQyxHQUFSLENBQVksc0JBQVosQ0FBQSxDQUFBO0FBQ0E7QUFBQTtXQUFBLDJDQUFBOzJCQUFBO0FBQ0UsUUFBQSxHQUFBLEdBQU0sSUFBQyxDQUFBLENBQUMsQ0FBQyxPQUFRLENBQUEsT0FBTyxDQUFDLFFBQVIsQ0FBakIsQ0FBQTtBQUNBLFFBQUEsSUFBWSxDQUFBLEdBQVo7QUFBQSxtQkFBQTtTQURBO0FBQUE7O0FBRUE7QUFBQTtlQUFBLDhDQUFBOzZCQUFBO0FBQ0UsWUFBQSxJQUFZLElBQUksQ0FBQyxJQUFMLEtBQWEsV0FBekI7QUFBQSx1QkFBQTthQUFBO0FBQUEsWUFDQSxLQUFBLEdBQVEsR0FBSSxDQUFBLElBQUksQ0FBQyxPQUFMLENBRFosQ0FBQTtBQUVBLFlBQUEsSUFBc0IsYUFBdEI7NkJBQUEsSUFBSSxDQUFDLEtBQUwsR0FBYSxPQUFiO2FBQUEsTUFBQTtxQ0FBQTthQUhGO0FBQUE7O2FBRkEsQ0FERjtBQUFBO3NCQUZpQjtJQUFBLENBbkRuQixDQUFBOztBQUFBLDZCQTZEQSxjQUFBLEdBQWdCLFNBQUMsY0FBRCxHQUFBOztRQUFDLGlCQUFpQjtPQUNoQzthQUFBLFVBQUEsQ0FBVyxJQUFDLENBQUEsYUFBWixFQUEyQixDQUEzQixFQUE4QixjQUE5QixFQURjO0lBQUEsQ0E3RGhCLENBQUE7O0FBQUEsNkJBZ0VBLGFBQUEsR0FBZSxTQUFDLGNBQUQsR0FBQTtBQUNiLFVBQUEsUUFBQTtBQUFBLE1BQUEsUUFBQSxHQUFXLE9BQUEsQ0FBUSxxQkFBUixDQUFYLENBQUE7YUFDQSxRQUFRLENBQUMsSUFBVCxDQUFBLEVBRmE7SUFBQSxDQWhFZixDQUFBOztBQUFBLDZCQW9FQSxNQUFBLEdBQ0U7QUFBQSxNQUFBLE9BQUEsRUFDRTtBQUFBLFFBQUEsS0FBQSxFQUFPLE1BQVA7QUFBQSxRQUNBLFdBQUEsRUFBYSxzQ0FEYjtBQUFBLFFBRUEsSUFBQSxFQUFNLFNBRk47QUFBQSxRQUdBLFNBQUEsRUFBUyxJQUhUO09BREY7QUFBQSxNQUtBLFVBQUEsRUFDRTtBQUFBLFFBQUEsS0FBQSxFQUFPLE1BQVA7QUFBQSxRQUNBLFdBQUEsRUFBYSxzQ0FEYjtBQUFBLFFBRUEsSUFBQSxFQUFNLFNBRk47QUFBQSxRQUdBLFNBQUEsRUFBUyxJQUhUO09BTkY7QUFBQSxNQVVBLFVBQUEsRUFDRTtBQUFBLFFBQUEsS0FBQSxFQUFPLFFBQVA7QUFBQSxRQUNBLFdBQUEsRUFBYSx3Q0FEYjtBQUFBLFFBRUEsSUFBQSxFQUFNLFNBRk47QUFBQSxRQUdBLFNBQUEsRUFBUyxJQUhUO09BWEY7S0FyRUYsQ0FBQTs7MEJBQUE7O01BRkYsQ0FBQTs7QUFBQSxFQXVGQSxNQUFNLENBQUMsT0FBUCxHQUFxQixJQUFBLGNBQUEsQ0FBQSxDQXZGckIsQ0FBQTtBQUFBIgp9

//# sourceURL=/C:/Users/Administrator/.atom/packages/simplified-chinese-menu/lib/main.coffee
