(function() {
  module.exports = {
    personalAccessToken: {
      description: 'Your personal GitHub access token',
      type: 'string',
      "default": '',
      order: 1
    },
    gistId: {
      description: 'ID of gist to use for configuration storage',
      type: 'string',
      "default": '',
      order: 2
    },
    gistDescription: {
      description: 'The description of the gist',
      type: 'string',
      "default": 'automatic update by http://atom.io/packages/sync-settings',
      order: 3
    },
    syncSettings: {
      type: 'boolean',
      "default": true,
      order: 4
    },
    blacklistedKeys: {
      description: "Comma-seperated list of blacklisted keys (e.g. 'package-name,other-package-name.config-name')",
      type: 'array',
      "default": [],
      items: {
        type: 'string'
      },
      order: 5
    },
    syncPackages: {
      type: 'boolean',
      "default": true,
      order: 6
    },
    syncKeymap: {
      type: 'boolean',
      "default": true,
      order: 7
    },
    syncStyles: {
      type: 'boolean',
      "default": true,
      order: 8
    },
    syncInit: {
      type: 'boolean',
      "default": true,
      order: 9
    },
    syncSnippets: {
      type: 'boolean',
      "default": true,
      order: 10
    },
    extraFiles: {
      description: 'Comma-seperated list of files other than Atom\'s default config files in ~/.atom',
      type: 'array',
      "default": [],
      items: {
        type: 'string'
      },
      order: 11
    },
    checkForUpdatedBackup: {
      description: 'Check for newer backup on Atom start',
      type: 'boolean',
      "default": true,
      order: 12
    },
    _lastBackupHash: {
      type: 'string',
      "default": '',
      description: 'Hash of the last backup restored or created',
      order: 13
    },
    quietUpdateCheck: {
      type: 'boolean',
      "default": false,
      description: "Mute 'Latest backup is already applied' message",
      order: 14
    }
  };

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiZmlsZTovLy9DOi9Vc2Vycy9BZG1pbmlzdHJhdG9yLy5hdG9tL3BhY2thZ2VzL3N5bmMtc2V0dGluZ3MvbGliL2NvbmZpZy5jb2ZmZWUiCiAgXSwKICAibmFtZXMiOiBbXSwKICAibWFwcGluZ3MiOiAiQUFBQTtBQUFBLEVBQUEsTUFBTSxDQUFDLE9BQVAsR0FBaUI7QUFBQSxJQUNmLG1CQUFBLEVBQ0U7QUFBQSxNQUFBLFdBQUEsRUFBYSxtQ0FBYjtBQUFBLE1BQ0EsSUFBQSxFQUFNLFFBRE47QUFBQSxNQUVBLFNBQUEsRUFBUyxFQUZUO0FBQUEsTUFHQSxLQUFBLEVBQU8sQ0FIUDtLQUZhO0FBQUEsSUFNZixNQUFBLEVBQ0U7QUFBQSxNQUFBLFdBQUEsRUFBYSw2Q0FBYjtBQUFBLE1BQ0EsSUFBQSxFQUFNLFFBRE47QUFBQSxNQUVBLFNBQUEsRUFBUyxFQUZUO0FBQUEsTUFHQSxLQUFBLEVBQU8sQ0FIUDtLQVBhO0FBQUEsSUFXZixlQUFBLEVBQ0U7QUFBQSxNQUFBLFdBQUEsRUFBYSw2QkFBYjtBQUFBLE1BQ0EsSUFBQSxFQUFNLFFBRE47QUFBQSxNQUVBLFNBQUEsRUFBUywyREFGVDtBQUFBLE1BR0EsS0FBQSxFQUFPLENBSFA7S0FaYTtBQUFBLElBZ0JmLFlBQUEsRUFDRTtBQUFBLE1BQUEsSUFBQSxFQUFNLFNBQU47QUFBQSxNQUNBLFNBQUEsRUFBUyxJQURUO0FBQUEsTUFFQSxLQUFBLEVBQU8sQ0FGUDtLQWpCYTtBQUFBLElBb0JmLGVBQUEsRUFDRTtBQUFBLE1BQUEsV0FBQSxFQUFhLCtGQUFiO0FBQUEsTUFDQSxJQUFBLEVBQU0sT0FETjtBQUFBLE1BRUEsU0FBQSxFQUFTLEVBRlQ7QUFBQSxNQUdBLEtBQUEsRUFDRTtBQUFBLFFBQUEsSUFBQSxFQUFNLFFBQU47T0FKRjtBQUFBLE1BS0EsS0FBQSxFQUFPLENBTFA7S0FyQmE7QUFBQSxJQTJCZixZQUFBLEVBQ0U7QUFBQSxNQUFBLElBQUEsRUFBTSxTQUFOO0FBQUEsTUFDQSxTQUFBLEVBQVMsSUFEVDtBQUFBLE1BRUEsS0FBQSxFQUFPLENBRlA7S0E1QmE7QUFBQSxJQStCZixVQUFBLEVBQ0U7QUFBQSxNQUFBLElBQUEsRUFBTSxTQUFOO0FBQUEsTUFDQSxTQUFBLEVBQVMsSUFEVDtBQUFBLE1BRUEsS0FBQSxFQUFPLENBRlA7S0FoQ2E7QUFBQSxJQW1DZixVQUFBLEVBQ0U7QUFBQSxNQUFBLElBQUEsRUFBTSxTQUFOO0FBQUEsTUFDQSxTQUFBLEVBQVMsSUFEVDtBQUFBLE1BRUEsS0FBQSxFQUFPLENBRlA7S0FwQ2E7QUFBQSxJQXVDZixRQUFBLEVBQ0U7QUFBQSxNQUFBLElBQUEsRUFBTSxTQUFOO0FBQUEsTUFDQSxTQUFBLEVBQVMsSUFEVDtBQUFBLE1BRUEsS0FBQSxFQUFPLENBRlA7S0F4Q2E7QUFBQSxJQTJDZixZQUFBLEVBQ0U7QUFBQSxNQUFBLElBQUEsRUFBTSxTQUFOO0FBQUEsTUFDQSxTQUFBLEVBQVMsSUFEVDtBQUFBLE1BRUEsS0FBQSxFQUFPLEVBRlA7S0E1Q2E7QUFBQSxJQStDZixVQUFBLEVBQ0U7QUFBQSxNQUFBLFdBQUEsRUFBYSxrRkFBYjtBQUFBLE1BQ0EsSUFBQSxFQUFNLE9BRE47QUFBQSxNQUVBLFNBQUEsRUFBUyxFQUZUO0FBQUEsTUFHQSxLQUFBLEVBQ0U7QUFBQSxRQUFBLElBQUEsRUFBTSxRQUFOO09BSkY7QUFBQSxNQUtBLEtBQUEsRUFBTyxFQUxQO0tBaERhO0FBQUEsSUFzRGYscUJBQUEsRUFDRTtBQUFBLE1BQUEsV0FBQSxFQUFhLHNDQUFiO0FBQUEsTUFDQSxJQUFBLEVBQU0sU0FETjtBQUFBLE1BRUEsU0FBQSxFQUFTLElBRlQ7QUFBQSxNQUdBLEtBQUEsRUFBTyxFQUhQO0tBdkRhO0FBQUEsSUEyRGYsZUFBQSxFQUNFO0FBQUEsTUFBQSxJQUFBLEVBQU0sUUFBTjtBQUFBLE1BQ0EsU0FBQSxFQUFTLEVBRFQ7QUFBQSxNQUVBLFdBQUEsRUFBYSw2Q0FGYjtBQUFBLE1BR0EsS0FBQSxFQUFPLEVBSFA7S0E1RGE7QUFBQSxJQWdFZixnQkFBQSxFQUNFO0FBQUEsTUFBQSxJQUFBLEVBQU0sU0FBTjtBQUFBLE1BQ0EsU0FBQSxFQUFTLEtBRFQ7QUFBQSxNQUVBLFdBQUEsRUFBYSxpREFGYjtBQUFBLE1BR0EsS0FBQSxFQUFPLEVBSFA7S0FqRWE7R0FBakIsQ0FBQTtBQUFBIgp9

//# sourceURL=/C:/Users/Administrator/.atom/packages/sync-settings/lib/config.coffee
