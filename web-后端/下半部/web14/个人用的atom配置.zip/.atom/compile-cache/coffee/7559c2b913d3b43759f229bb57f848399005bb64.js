(function() {
  var CSON, S, Settings, applyButtonToolbar, applyHtmlWithOrg, applyInstallPanelOnSwitch, applySectionHeadings, applySpecialHeading, applyTextContentBySettingsId, applyTextWithOrg, applyToPanel, getTextMatchElement, isAlreadyLocalized;

  CSON = require('cson');

  S = CSON.load(__dirname + '/../def/settings.cson');

  applyToPanel = function(e) {
    var d, info, inst, span, sv, tc, tp1, tp2, _i, _len, _ref;
    _ref = S.Settings.settings;
    for (_i = 0, _len = _ref.length; _i < _len; _i++) {
      d = _ref[_i];
      applyTextContentBySettingsId(d);
    }
    sv = document.querySelector('.settings-view');
    sv.querySelector('#core-settings-note').innerHTML = "下述为Atom核心部分的设置，个别扩展包可能拥有额外独立设置，浏览扩展包设置请在 <a class='link packages-open'>扩展包列表</a> 中选择对应名称扩展的设置。";
    sv.querySelector('#editor-settings-note').innerHTML = "下述为Atom文本编辑器部分的设置，其中一些设置将会基于每个语言覆盖，检查语言设置请在 <a class='link packages-open'>扩展包列表</a> 中选择对应语言扩展的设置。";
    sv.querySelector('[title="System Settings"]').closest('.panels-item').querySelector('.text').innerHTML = "这些设置可以将Atom集成到你的操作系统中。";
    info = sv.querySelector('.keybinding-panel>div:nth-child(2)');
    if (!isAlreadyLocalized(info)) {
      info.querySelector('span:nth-child(2)').textContent = "您可以覆盖这些按键绑定通过复制　";
      info.querySelector('span:nth-child(4)').textContent = "并且粘贴进";
      info.querySelector('a.link').textContent = " 用户键盘映射 ";
      span = document.createElement('span');
      span.textContent = "进行修改。";
      info.appendChild(span);
      info.setAttribute('data-localized', 'true');
    }
    info = sv.querySelector('.themes-panel>div>div:nth-child(2)');
    if (!isAlreadyLocalized(info)) {
      info.querySelector('span').textContent = "您也可以在";
      info.querySelector('a.link').textContent = " 用户样式设置 ";
      span = document.createElement('span');
      span.textContent = "中扩展 Atom 的样式。";
      info.appendChild(span);
      tp1 = sv.querySelector('.themes-picker>div:nth-child(1)');
      tp1.querySelector('.setting-title').textContent = "UI 主题";
      tp1.querySelector('.setting-description').textContent = "该主题将应用在标签，状态栏，树形视图和下拉菜单等。";
      tp2 = sv.querySelector('.themes-picker>div:nth-child(2)');
      tp2.querySelector('.setting-title').textContent = "语法主题";
      tp2.querySelector('.setting-description').textContent = "该主题将应用在编辑器内的文本。";
      info.setAttribute('data-localized', 'true');
    }
    applySpecialHeading(sv, "Available Updates", 2, "可用更新");
    applyTextWithOrg(sv.querySelector('.update-all-button.btn-primary'), "全部更新");
    applyTextWithOrg(sv.querySelector('.update-all-button:not(.btn-primary)'), "检查更新");
    applyTextWithOrg(sv.querySelector('.alert.icon-hourglass'), "检查更新中...");
    applyTextWithOrg(sv.querySelector('.alert.icon-heart'), "已安装的扩展都是最新的!");
    applySectionHeadings();
    inst = document.querySelector('div.section:not(.themes-panel)');
    info = inst.querySelector('.native-key-bindings');
    if (!isAlreadyLocalized(info)) {
      info.querySelector('span:nth-child(2)').textContent = "扩展·主题 ";
      tc = info.querySelector('span:nth-child(4)');
      tc.textContent = tc.textContent.replace("and are installed to", "它们将被安装在 ");
      info.setAttribute('data-localized', 'true');
    }
    applyTextWithOrg(inst.querySelector('.search-container .btn:nth-child(1)'), "扩展");
    applyTextWithOrg(inst.querySelector('.search-container .btn:nth-child(2)'), "主题");
    return applyButtonToolbar();
  };

  applyInstallPanelOnSwitch = function() {
    var info, inst;
    applySectionHeadings(true);
    applyButtonToolbar();
    inst = document.querySelector('div.section:not(.themes-panel)');
    info = inst.querySelector('.native-key-bindings');
    return info.querySelector('span:nth-child(2)').textContent = "扩展·主题 ";
  };

  applySpecialHeading = function(area, org, childIdx, text) {
    var sh, span;
    sh = getTextMatchElement(area, '.section-heading', org);
    if (!(sh && !isAlreadyLocalized(sh))) {
      return;
    }
    sh.childNodes[childIdx].textContent = null;
    span = document.createElement('span');
    span.textContent = org;
    applyTextWithOrg(span, text);
    return sh.appendChild(span);
  };

  applySectionHeadings = function(force) {
    var el, sh, sv, _i, _j, _len, _len1, _ref, _ref1, _results;
    sv = document.querySelector('.settings-view');
    _ref = S.Settings.sectionHeadings;
    for (_i = 0, _len = _ref.length; _i < _len; _i++) {
      sh = _ref[_i];
      el = getTextMatchElement(sv, '.section-heading', sh.label);
      if (!el) {
        continue;
      }
      if (!isAlreadyLocalized(el) && force) {
        applyTextWithOrg(el, sh.value);
      }
    }
    _ref1 = S.Settings.subSectionHeadings;
    _results = [];
    for (_j = 0, _len1 = _ref1.length; _j < _len1; _j++) {
      sh = _ref1[_j];
      el = getTextMatchElement(sv, '.sub-section-heading', sh.label);
      if (!el) {
        continue;
      }
      if (!isAlreadyLocalized(el) && force) {
        _results.push(applyTextWithOrg(el, sh.value));
      } else {
        _results.push(void 0);
      }
    }
    return _results;
  };

  applyButtonToolbar = function() {
    var btn, sv, _i, _j, _k, _l, _len, _len1, _len2, _len3, _len4, _m, _ref, _ref1, _ref2, _ref3, _ref4, _results;
    sv = document.querySelector('.settings-view');
    _ref = sv.querySelectorAll('.meta-controls .install-button');
    for (_i = 0, _len = _ref.length; _i < _len; _i++) {
      btn = _ref[_i];
      applyTextWithOrg(btn, "安装");
    }
    _ref1 = sv.querySelectorAll('.meta-controls .settings');
    for (_j = 0, _len1 = _ref1.length; _j < _len1; _j++) {
      btn = _ref1[_j];
      applyTextWithOrg(btn, "设置");
    }
    _ref2 = sv.querySelectorAll('.meta-controls .uninstall-button');
    for (_k = 0, _len2 = _ref2.length; _k < _len2; _k++) {
      btn = _ref2[_k];
      applyTextWithOrg(btn, "卸载");
    }
    _ref3 = sv.querySelectorAll('.meta-controls .icon-playback-pause span');
    for (_l = 0, _len3 = _ref3.length; _l < _len3; _l++) {
      btn = _ref3[_l];
      applyTextWithOrg(btn, "关闭");
    }
    _ref4 = sv.querySelectorAll('.meta-controls .icon-playback-play span');
    _results = [];
    for (_m = 0, _len4 = _ref4.length; _m < _len4; _m++) {
      btn = _ref4[_m];
      _results.push(applyTextWithOrg(btn, "启用"));
    }
    return _results;
  };

  getTextMatchElement = function(area, query, text) {
    var el, elems, result, _i, _len;
    elems = area.querySelectorAll(query);
    result;
    for (_i = 0, _len = elems.length; _i < _len; _i++) {
      el = elems[_i];
      if (el.textContent.includes(text)) {
        result = el;
        break;
      }
    }
    return result;
  };

  isAlreadyLocalized = function(elem) {
    var localized;
    if (elem) {
      localized = elem.getAttribute('data-localized');
    }
    return localized === 'true';
  };

  applyTextContentBySettingsId = function(data) {
    var before, ctrl, el, opt, options, _i, _len, _results;
    el = document.querySelector("[id='" + data.id + "']");
    if (!el) {
      return;
    }
    ctrl = el.closest('.control-group');
    applyTextWithOrg(ctrl.querySelector('.setting-title'), data.title);
    applyHtmlWithOrg(ctrl.querySelector('.setting-description'), data.desc);
    if (data.selectOptions) {
      options = el.querySelectorAll('option');
      _results = [];
      for (_i = 0, _len = options.length; _i < _len; _i++) {
        opt = options[_i];
        before = String(opt.textContent);
        _results.push(applyTextWithOrg(opt, data.selectOptions[before].value));
      }
      return _results;
    }
  };

  applyTextWithOrg = function(elem, text) {
    var before;
    if (!text) {
      return;
    }
    before = String(elem.textContent);
    if (before === text) {
      return;
    }
    elem.textContent = text;
    elem.setAttribute('title', before);
    return elem.setAttribute('data-localized', 'true');
  };

  applyHtmlWithOrg = function(elem, text) {
    var before;
    if (!text) {
      return;
    }
    before = String(elem.textContent);
    if (before === text) {
      return;
    }
    elem.innerHTML = text;
    elem.setAttribute('title', before);
    return elem.setAttribute('data-localized', 'true');
  };

  Settings = {
    init: function() {
      var btn, btns, d, e, el, ext, font, lastMenu, menu, panelMenus, pm, settingsEnabled, settingsTab, sv, _i, _j, _k, _len, _len1, _len2, _ref, _results;
      settingsTab = document.querySelector('.tab-bar [data-type="SettingsView"]');
      if (settingsTab) {
        settingsEnabled = settingsTab.className.includes('active');
      }
      if (!(settingsTab && settingsEnabled)) {
        return;
      }
      try {
        sv = document.querySelector('.settings-view');
        if (process.platform === 'win32') {
          font = atom.config.get('editor.fontFamily');
          if (font) {
            sv.style["fontFamily"] = font;
          } else {
            sv.style["fontFamily"] = "'Segoe UI', Microsoft Yahei, sans-serif";
            sv.style["fontSize"] = "12px";
          }
        }
        lastMenu = sv.querySelector('.panels-menu .active a');
        panelMenus = sv.querySelectorAll('.settings-view .panels-menu li a');
        for (_i = 0, _len = panelMenus.length; _i < _len; _i++) {
          pm = panelMenus[_i];
          pm.click();
          pm.addEventListener('click', applyInstallPanelOnSwitch);
        }
        if (lastMenu) {
          lastMenu.click();
        }
        applyToPanel();
        menu = sv.querySelector('.settings-view .panels-menu');
        if (!menu) {
          return;
        }
        _ref = S.Settings.menu;
        for (_j = 0, _len1 = _ref.length; _j < _len1; _j++) {
          d = _ref[_j];
          el = menu.querySelector("[name='" + d.label + "']>a");
          applyTextWithOrg(el, d.value);
        }
        ext = sv.querySelector('.settings-view .icon-link-external');
        applyTextWithOrg(ext, "打开插件源码目录");
        btns = sv.querySelectorAll('div.section:not(.themes-panel) .search-container .btn');
        _results = [];
        for (_k = 0, _len2 = btns.length; _k < _len2; _k++) {
          btn = btns[_k];
          _results.push(btn.addEventListener('click', applyInstallPanelOnSwitch));
        }
        return _results;
      } catch (_error) {
        e = _error;
        return console.error("软件汉化失败。", e);
      }
    }
  };

  module.exports = Settings;

}).call(this);

//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAiZmlsZSI6ICIiLAogICJzb3VyY2VSb290IjogIiIsCiAgInNvdXJjZXMiOiBbCiAgICAiZmlsZTovLy9DOi9Vc2Vycy9BZG1pbmlzdHJhdG9yLy5hdG9tL3BhY2thZ2VzL3NpbXBsaWZpZWQtY2hpbmVzZS1tZW51L3Rvb2xzL3NldHRpbmdzLmNvZmZlZSIKICBdLAogICJuYW1lcyI6IFtdLAogICJtYXBwaW5ncyI6ICJBQUFBO0FBQUEsTUFBQSxvT0FBQTs7QUFBQSxFQUFBLElBQUEsR0FBTyxPQUFBLENBQVEsTUFBUixDQUFQLENBQUE7O0FBQUEsRUFFQSxDQUFBLEdBQUksSUFBSSxDQUFDLElBQUwsQ0FBVSxTQUFBLEdBQVksdUJBQXRCLENBRkosQ0FBQTs7QUFBQSxFQUlBLFlBQUEsR0FBZSxTQUFDLENBQUQsR0FBQTtBQUViLFFBQUEscURBQUE7QUFBQTtBQUFBLFNBQUEsMkNBQUE7bUJBQUE7QUFDRSxNQUFBLDRCQUFBLENBQTZCLENBQTdCLENBQUEsQ0FERjtBQUFBLEtBQUE7QUFBQSxJQUdBLEVBQUEsR0FBSyxRQUFRLENBQUMsYUFBVCxDQUF1QixnQkFBdkIsQ0FITCxDQUFBO0FBQUEsSUFLQSxFQUFFLENBQUMsYUFBSCxDQUFpQixxQkFBakIsQ0FBdUMsQ0FBQyxTQUF4QyxHQUFvRCxnR0FMcEQsQ0FBQTtBQUFBLElBTUEsRUFBRSxDQUFDLGFBQUgsQ0FBaUIsdUJBQWpCLENBQXlDLENBQUMsU0FBMUMsR0FBc0QsbUdBTnRELENBQUE7QUFBQSxJQVFBLEVBQUUsQ0FBQyxhQUFILENBQWlCLDJCQUFqQixDQUE2QyxDQUFDLE9BQTlDLENBQXNELGNBQXRELENBQXFFLENBQUMsYUFBdEUsQ0FBb0YsT0FBcEYsQ0FBNEYsQ0FBQyxTQUE3RixHQUF5Ryx3QkFSekcsQ0FBQTtBQUFBLElBVUEsSUFBQSxHQUFPLEVBQUUsQ0FBQyxhQUFILENBQWlCLG9DQUFqQixDQVZQLENBQUE7QUFXQSxJQUFBLElBQUEsQ0FBQSxrQkFBTyxDQUFtQixJQUFuQixDQUFQO0FBQ0UsTUFBQSxJQUFJLENBQUMsYUFBTCxDQUFtQixtQkFBbkIsQ0FBdUMsQ0FBQyxXQUF4QyxHQUFzRCxrQkFBdEQsQ0FBQTtBQUFBLE1BQ0EsSUFBSSxDQUFDLGFBQUwsQ0FBbUIsbUJBQW5CLENBQXVDLENBQUMsV0FBeEMsR0FBc0QsT0FEdEQsQ0FBQTtBQUFBLE1BRUEsSUFBSSxDQUFDLGFBQUwsQ0FBbUIsUUFBbkIsQ0FBNEIsQ0FBQyxXQUE3QixHQUEyQyxVQUYzQyxDQUFBO0FBQUEsTUFHQSxJQUFBLEdBQU8sUUFBUSxDQUFDLGFBQVQsQ0FBdUIsTUFBdkIsQ0FIUCxDQUFBO0FBQUEsTUFJQSxJQUFJLENBQUMsV0FBTCxHQUFtQixPQUpuQixDQUFBO0FBQUEsTUFLQSxJQUFJLENBQUMsV0FBTCxDQUFpQixJQUFqQixDQUxBLENBQUE7QUFBQSxNQU1BLElBQUksQ0FBQyxZQUFMLENBQWtCLGdCQUFsQixFQUFvQyxNQUFwQyxDQU5BLENBREY7S0FYQTtBQUFBLElBcUJBLElBQUEsR0FBTyxFQUFFLENBQUMsYUFBSCxDQUFpQixvQ0FBakIsQ0FyQlAsQ0FBQTtBQXNCQSxJQUFBLElBQUEsQ0FBQSxrQkFBTyxDQUFtQixJQUFuQixDQUFQO0FBQ0UsTUFBQSxJQUFJLENBQUMsYUFBTCxDQUFtQixNQUFuQixDQUEwQixDQUFDLFdBQTNCLEdBQXlDLE9BQXpDLENBQUE7QUFBQSxNQUNBLElBQUksQ0FBQyxhQUFMLENBQW1CLFFBQW5CLENBQTRCLENBQUMsV0FBN0IsR0FBMkMsVUFEM0MsQ0FBQTtBQUFBLE1BRUEsSUFBQSxHQUFPLFFBQVEsQ0FBQyxhQUFULENBQXVCLE1BQXZCLENBRlAsQ0FBQTtBQUFBLE1BR0EsSUFBSSxDQUFDLFdBQUwsR0FBbUIsZUFIbkIsQ0FBQTtBQUFBLE1BS0EsSUFBSSxDQUFDLFdBQUwsQ0FBaUIsSUFBakIsQ0FMQSxDQUFBO0FBQUEsTUFNQSxHQUFBLEdBQU0sRUFBRSxDQUFDLGFBQUgsQ0FBaUIsaUNBQWpCLENBTk4sQ0FBQTtBQUFBLE1BT0EsR0FBRyxDQUFDLGFBQUosQ0FBa0IsZ0JBQWxCLENBQW1DLENBQUMsV0FBcEMsR0FBa0QsT0FQbEQsQ0FBQTtBQUFBLE1BUUEsR0FBRyxDQUFDLGFBQUosQ0FBa0Isc0JBQWxCLENBQXlDLENBQUMsV0FBMUMsR0FBd0QsMkJBUnhELENBQUE7QUFBQSxNQVNBLEdBQUEsR0FBTSxFQUFFLENBQUMsYUFBSCxDQUFpQixpQ0FBakIsQ0FUTixDQUFBO0FBQUEsTUFVQSxHQUFHLENBQUMsYUFBSixDQUFrQixnQkFBbEIsQ0FBbUMsQ0FBQyxXQUFwQyxHQUFrRCxNQVZsRCxDQUFBO0FBQUEsTUFXQSxHQUFHLENBQUMsYUFBSixDQUFrQixzQkFBbEIsQ0FBeUMsQ0FBQyxXQUExQyxHQUF3RCxpQkFYeEQsQ0FBQTtBQUFBLE1BWUEsSUFBSSxDQUFDLFlBQUwsQ0FBa0IsZ0JBQWxCLEVBQW9DLE1BQXBDLENBWkEsQ0FERjtLQXRCQTtBQUFBLElBc0NBLG1CQUFBLENBQW9CLEVBQXBCLEVBQXdCLG1CQUF4QixFQUE2QyxDQUE3QyxFQUFnRCxNQUFoRCxDQXRDQSxDQUFBO0FBQUEsSUF1Q0EsZ0JBQUEsQ0FBaUIsRUFBRSxDQUFDLGFBQUgsQ0FBaUIsZ0NBQWpCLENBQWpCLEVBQXFFLE1BQXJFLENBdkNBLENBQUE7QUFBQSxJQXdDQSxnQkFBQSxDQUFpQixFQUFFLENBQUMsYUFBSCxDQUFpQixzQ0FBakIsQ0FBakIsRUFBMkUsTUFBM0UsQ0F4Q0EsQ0FBQTtBQUFBLElBeUNBLGdCQUFBLENBQWlCLEVBQUUsQ0FBQyxhQUFILENBQWlCLHVCQUFqQixDQUFqQixFQUE0RCxVQUE1RCxDQXpDQSxDQUFBO0FBQUEsSUEwQ0EsZ0JBQUEsQ0FBaUIsRUFBRSxDQUFDLGFBQUgsQ0FBaUIsbUJBQWpCLENBQWpCLEVBQXdELGNBQXhELENBMUNBLENBQUE7QUFBQSxJQTZDQSxvQkFBQSxDQUFBLENBN0NBLENBQUE7QUFBQSxJQThDQSxJQUFBLEdBQU8sUUFBUSxDQUFDLGFBQVQsQ0FBdUIsZ0NBQXZCLENBOUNQLENBQUE7QUFBQSxJQStDQSxJQUFBLEdBQU8sSUFBSSxDQUFDLGFBQUwsQ0FBbUIsc0JBQW5CLENBL0NQLENBQUE7QUFnREEsSUFBQSxJQUFBLENBQUEsa0JBQU8sQ0FBbUIsSUFBbkIsQ0FBUDtBQUNFLE1BQUEsSUFBSSxDQUFDLGFBQUwsQ0FBbUIsbUJBQW5CLENBQXVDLENBQUMsV0FBeEMsR0FBc0QsUUFBdEQsQ0FBQTtBQUFBLE1BQ0EsRUFBQSxHQUFLLElBQUksQ0FBQyxhQUFMLENBQW1CLG1CQUFuQixDQURMLENBQUE7QUFBQSxNQUVBLEVBQUUsQ0FBQyxXQUFILEdBQWlCLEVBQUUsQ0FBQyxXQUFXLENBQUMsT0FBZixDQUF1QixzQkFBdkIsRUFBK0MsVUFBL0MsQ0FGakIsQ0FBQTtBQUFBLE1BSUEsSUFBSSxDQUFDLFlBQUwsQ0FBa0IsZ0JBQWxCLEVBQW9DLE1BQXBDLENBSkEsQ0FERjtLQWhEQTtBQUFBLElBc0RBLGdCQUFBLENBQWlCLElBQUksQ0FBQyxhQUFMLENBQW1CLHFDQUFuQixDQUFqQixFQUE0RSxJQUE1RSxDQXREQSxDQUFBO0FBQUEsSUF1REEsZ0JBQUEsQ0FBaUIsSUFBSSxDQUFDLGFBQUwsQ0FBbUIscUNBQW5CLENBQWpCLEVBQTRFLElBQTVFLENBdkRBLENBQUE7V0EwREEsa0JBQUEsQ0FBQSxFQTVEYTtFQUFBLENBSmYsQ0FBQTs7QUFBQSxFQWtFQSx5QkFBQSxHQUE0QixTQUFBLEdBQUE7QUFDMUIsUUFBQSxVQUFBO0FBQUEsSUFBQSxvQkFBQSxDQUFxQixJQUFyQixDQUFBLENBQUE7QUFBQSxJQUNBLGtCQUFBLENBQUEsQ0FEQSxDQUFBO0FBQUEsSUFFQSxJQUFBLEdBQU8sUUFBUSxDQUFDLGFBQVQsQ0FBdUIsZ0NBQXZCLENBRlAsQ0FBQTtBQUFBLElBR0EsSUFBQSxHQUFPLElBQUksQ0FBQyxhQUFMLENBQW1CLHNCQUFuQixDQUhQLENBQUE7V0FJQSxJQUFJLENBQUMsYUFBTCxDQUFtQixtQkFBbkIsQ0FBdUMsQ0FBQyxXQUF4QyxHQUFzRCxTQUw1QjtFQUFBLENBbEU1QixDQUFBOztBQUFBLEVBeUVBLG1CQUFBLEdBQXNCLFNBQUMsSUFBRCxFQUFPLEdBQVAsRUFBWSxRQUFaLEVBQXNCLElBQXRCLEdBQUE7QUFDcEIsUUFBQSxRQUFBO0FBQUEsSUFBQSxFQUFBLEdBQUssbUJBQUEsQ0FBb0IsSUFBcEIsRUFBMEIsa0JBQTFCLEVBQThDLEdBQTlDLENBQUwsQ0FBQTtBQUNBLElBQUEsSUFBQSxDQUFBLENBQWMsRUFBQSxJQUFNLENBQUEsa0JBQUMsQ0FBbUIsRUFBbkIsQ0FBckIsQ0FBQTtBQUFBLFlBQUEsQ0FBQTtLQURBO0FBQUEsSUFFQSxFQUFFLENBQUMsVUFBVyxDQUFBLFFBQUEsQ0FBUyxDQUFDLFdBQXhCLEdBQXNDLElBRnRDLENBQUE7QUFBQSxJQUdBLElBQUEsR0FBTyxRQUFRLENBQUMsYUFBVCxDQUF1QixNQUF2QixDQUhQLENBQUE7QUFBQSxJQUlBLElBQUksQ0FBQyxXQUFMLEdBQW1CLEdBSm5CLENBQUE7QUFBQSxJQUtBLGdCQUFBLENBQWlCLElBQWpCLEVBQXVCLElBQXZCLENBTEEsQ0FBQTtXQU1BLEVBQUUsQ0FBQyxXQUFILENBQWUsSUFBZixFQVBvQjtFQUFBLENBekV0QixDQUFBOztBQUFBLEVBa0ZBLG9CQUFBLEdBQXVCLFNBQUMsS0FBRCxHQUFBO0FBQ3JCLFFBQUEsc0RBQUE7QUFBQSxJQUFBLEVBQUEsR0FBSyxRQUFRLENBQUMsYUFBVCxDQUF1QixnQkFBdkIsQ0FBTCxDQUFBO0FBQ0E7QUFBQSxTQUFBLDJDQUFBO29CQUFBO0FBQ0UsTUFBQSxFQUFBLEdBQUssbUJBQUEsQ0FBb0IsRUFBcEIsRUFBd0Isa0JBQXhCLEVBQTRDLEVBQUUsQ0FBQyxLQUEvQyxDQUFMLENBQUE7QUFDQSxNQUFBLElBQUEsQ0FBQSxFQUFBO0FBQUEsaUJBQUE7T0FEQTtBQUVBLE1BQUEsSUFBRyxDQUFBLGtCQUFDLENBQW1CLEVBQW5CLENBQUQsSUFBNEIsS0FBL0I7QUFDRSxRQUFBLGdCQUFBLENBQWlCLEVBQWpCLEVBQXFCLEVBQUUsQ0FBQyxLQUF4QixDQUFBLENBREY7T0FIRjtBQUFBLEtBREE7QUFNQTtBQUFBO1NBQUEsOENBQUE7cUJBQUE7QUFDRSxNQUFBLEVBQUEsR0FBSyxtQkFBQSxDQUFvQixFQUFwQixFQUF3QixzQkFBeEIsRUFBZ0QsRUFBRSxDQUFDLEtBQW5ELENBQUwsQ0FBQTtBQUNBLE1BQUEsSUFBQSxDQUFBLEVBQUE7QUFBQSxpQkFBQTtPQURBO0FBRUEsTUFBQSxJQUFHLENBQUEsa0JBQUMsQ0FBbUIsRUFBbkIsQ0FBRCxJQUE0QixLQUEvQjtzQkFDRSxnQkFBQSxDQUFpQixFQUFqQixFQUFxQixFQUFFLENBQUMsS0FBeEIsR0FERjtPQUFBLE1BQUE7OEJBQUE7T0FIRjtBQUFBO29CQVBxQjtFQUFBLENBbEZ2QixDQUFBOztBQUFBLEVBK0ZBLGtCQUFBLEdBQXFCLFNBQUEsR0FBQTtBQUNuQixRQUFBLHlHQUFBO0FBQUEsSUFBQSxFQUFBLEdBQUssUUFBUSxDQUFDLGFBQVQsQ0FBdUIsZ0JBQXZCLENBQUwsQ0FBQTtBQUNBO0FBQUEsU0FBQSwyQ0FBQTtxQkFBQTtBQUNFLE1BQUEsZ0JBQUEsQ0FBaUIsR0FBakIsRUFBc0IsSUFBdEIsQ0FBQSxDQURGO0FBQUEsS0FEQTtBQUdBO0FBQUEsU0FBQSw4Q0FBQTtzQkFBQTtBQUNFLE1BQUEsZ0JBQUEsQ0FBaUIsR0FBakIsRUFBc0IsSUFBdEIsQ0FBQSxDQURGO0FBQUEsS0FIQTtBQUtBO0FBQUEsU0FBQSw4Q0FBQTtzQkFBQTtBQUNFLE1BQUEsZ0JBQUEsQ0FBaUIsR0FBakIsRUFBc0IsSUFBdEIsQ0FBQSxDQURGO0FBQUEsS0FMQTtBQU9BO0FBQUEsU0FBQSw4Q0FBQTtzQkFBQTtBQUNFLE1BQUEsZ0JBQUEsQ0FBaUIsR0FBakIsRUFBc0IsSUFBdEIsQ0FBQSxDQURGO0FBQUEsS0FQQTtBQVNBO0FBQUE7U0FBQSw4Q0FBQTtzQkFBQTtBQUNFLG9CQUFBLGdCQUFBLENBQWlCLEdBQWpCLEVBQXNCLElBQXRCLEVBQUEsQ0FERjtBQUFBO29CQVZtQjtFQUFBLENBL0ZyQixDQUFBOztBQUFBLEVBNEdBLG1CQUFBLEdBQXNCLFNBQUMsSUFBRCxFQUFPLEtBQVAsRUFBYyxJQUFkLEdBQUE7QUFDcEIsUUFBQSwyQkFBQTtBQUFBLElBQUEsS0FBQSxHQUFRLElBQUksQ0FBQyxnQkFBTCxDQUFzQixLQUF0QixDQUFSLENBQUE7QUFBQSxJQUNBLE1BREEsQ0FBQTtBQUVBLFNBQUEsNENBQUE7cUJBQUE7QUFDRSxNQUFBLElBQUcsRUFBRSxDQUFDLFdBQVcsQ0FBQyxRQUFmLENBQXdCLElBQXhCLENBQUg7QUFDRSxRQUFBLE1BQUEsR0FBUyxFQUFULENBQUE7QUFDQSxjQUZGO09BREY7QUFBQSxLQUZBO0FBTUEsV0FBTyxNQUFQLENBUG9CO0VBQUEsQ0E1R3RCLENBQUE7O0FBQUEsRUFxSEEsa0JBQUEsR0FBcUIsU0FBQyxJQUFELEdBQUE7QUFDbkIsUUFBQSxTQUFBO0FBQUEsSUFBQSxJQUFtRCxJQUFuRDtBQUFBLE1BQUEsU0FBQSxHQUFZLElBQUksQ0FBQyxZQUFMLENBQWtCLGdCQUFsQixDQUFaLENBQUE7S0FBQTtBQUNBLFdBQU8sU0FBQSxLQUFhLE1BQXBCLENBRm1CO0VBQUEsQ0FySHJCLENBQUE7O0FBQUEsRUF5SEEsNEJBQUEsR0FBK0IsU0FBQyxJQUFELEdBQUE7QUFDN0IsUUFBQSxrREFBQTtBQUFBLElBQUEsRUFBQSxHQUFLLFFBQVEsQ0FBQyxhQUFULENBQXdCLE9BQUEsR0FBTyxJQUFJLENBQUMsRUFBWixHQUFlLElBQXZDLENBQUwsQ0FBQTtBQUNBLElBQUEsSUFBQSxDQUFBLEVBQUE7QUFBQSxZQUFBLENBQUE7S0FEQTtBQUFBLElBRUEsSUFBQSxHQUFPLEVBQUUsQ0FBQyxPQUFILENBQVcsZ0JBQVgsQ0FGUCxDQUFBO0FBQUEsSUFHQSxnQkFBQSxDQUFpQixJQUFJLENBQUMsYUFBTCxDQUFtQixnQkFBbkIsQ0FBakIsRUFBdUQsSUFBSSxDQUFDLEtBQTVELENBSEEsQ0FBQTtBQUFBLElBSUEsZ0JBQUEsQ0FBaUIsSUFBSSxDQUFDLGFBQUwsQ0FBbUIsc0JBQW5CLENBQWpCLEVBQTZELElBQUksQ0FBQyxJQUFsRSxDQUpBLENBQUE7QUFLQSxJQUFBLElBQUcsSUFBSSxDQUFDLGFBQVI7QUFDRSxNQUFBLE9BQUEsR0FBVSxFQUFFLENBQUMsZ0JBQUgsQ0FBb0IsUUFBcEIsQ0FBVixDQUFBO0FBQ0E7V0FBQSw4Q0FBQTswQkFBQTtBQUNFLFFBQUEsTUFBQSxHQUFTLE1BQUEsQ0FBTyxHQUFHLENBQUMsV0FBWCxDQUFULENBQUE7QUFBQSxzQkFDQSxnQkFBQSxDQUFpQixHQUFqQixFQUFzQixJQUFJLENBQUMsYUFBYyxDQUFBLE1BQUEsQ0FBTyxDQUFDLEtBQWpELEVBREEsQ0FERjtBQUFBO3NCQUZGO0tBTjZCO0VBQUEsQ0F6SC9CLENBQUE7O0FBQUEsRUFxSUEsZ0JBQUEsR0FBbUIsU0FBQyxJQUFELEVBQU8sSUFBUCxHQUFBO0FBQ2pCLFFBQUEsTUFBQTtBQUFBLElBQUEsSUFBQSxDQUFBLElBQUE7QUFBQSxZQUFBLENBQUE7S0FBQTtBQUFBLElBQ0EsTUFBQSxHQUFTLE1BQUEsQ0FBTyxJQUFJLENBQUMsV0FBWixDQURULENBQUE7QUFFQSxJQUFBLElBQVUsTUFBQSxLQUFVLElBQXBCO0FBQUEsWUFBQSxDQUFBO0tBRkE7QUFBQSxJQUdBLElBQUksQ0FBQyxXQUFMLEdBQW1CLElBSG5CLENBQUE7QUFBQSxJQUlBLElBQUksQ0FBQyxZQUFMLENBQWtCLE9BQWxCLEVBQTJCLE1BQTNCLENBSkEsQ0FBQTtXQUtBLElBQUksQ0FBQyxZQUFMLENBQWtCLGdCQUFsQixFQUFvQyxNQUFwQyxFQU5pQjtFQUFBLENBckluQixDQUFBOztBQUFBLEVBNklBLGdCQUFBLEdBQW1CLFNBQUMsSUFBRCxFQUFPLElBQVAsR0FBQTtBQUNqQixRQUFBLE1BQUE7QUFBQSxJQUFBLElBQUEsQ0FBQSxJQUFBO0FBQUEsWUFBQSxDQUFBO0tBQUE7QUFBQSxJQUNBLE1BQUEsR0FBUyxNQUFBLENBQU8sSUFBSSxDQUFDLFdBQVosQ0FEVCxDQUFBO0FBRUEsSUFBQSxJQUFVLE1BQUEsS0FBVSxJQUFwQjtBQUFBLFlBQUEsQ0FBQTtLQUZBO0FBQUEsSUFHQSxJQUFJLENBQUMsU0FBTCxHQUFpQixJQUhqQixDQUFBO0FBQUEsSUFJQSxJQUFJLENBQUMsWUFBTCxDQUFrQixPQUFsQixFQUEyQixNQUEzQixDQUpBLENBQUE7V0FLQSxJQUFJLENBQUMsWUFBTCxDQUFrQixnQkFBbEIsRUFBb0MsTUFBcEMsRUFOaUI7RUFBQSxDQTdJbkIsQ0FBQTs7QUFBQSxFQXNKQSxRQUFBLEdBQ0U7QUFBQSxJQUFBLElBQUEsRUFBTyxTQUFBLEdBQUE7QUFDTCxVQUFBLGdKQUFBO0FBQUEsTUFBQSxXQUFBLEdBQWMsUUFBUSxDQUFDLGFBQVQsQ0FBdUIscUNBQXZCLENBQWQsQ0FBQTtBQUNBLE1BQUEsSUFBNkQsV0FBN0Q7QUFBQSxRQUFBLGVBQUEsR0FBa0IsV0FBVyxDQUFDLFNBQVMsQ0FBQyxRQUF0QixDQUErQixRQUEvQixDQUFsQixDQUFBO09BREE7QUFFQSxNQUFBLElBQUEsQ0FBQSxDQUFjLFdBQUEsSUFBZSxlQUE3QixDQUFBO0FBQUEsY0FBQSxDQUFBO09BRkE7QUFHQTtBQUdFLFFBQUEsRUFBQSxHQUFLLFFBQVEsQ0FBQyxhQUFULENBQXVCLGdCQUF2QixDQUFMLENBQUE7QUFHQSxRQUFBLElBQUcsT0FBTyxDQUFDLFFBQVIsS0FBb0IsT0FBdkI7QUFDRSxVQUFBLElBQUEsR0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQVosQ0FBZ0IsbUJBQWhCLENBQVAsQ0FBQTtBQUNBLFVBQUEsSUFBRyxJQUFIO0FBQ0UsWUFBQSxFQUFFLENBQUMsS0FBTSxDQUFBLFlBQUEsQ0FBVCxHQUF5QixJQUF6QixDQURGO1dBQUEsTUFBQTtBQUdFLFlBQUEsRUFBRSxDQUFDLEtBQU0sQ0FBQSxZQUFBLENBQVQsR0FBeUIseUNBQXpCLENBQUE7QUFBQSxZQUNBLEVBQUUsQ0FBQyxLQUFNLENBQUEsVUFBQSxDQUFULEdBQXVCLE1BRHZCLENBSEY7V0FGRjtTQUhBO0FBQUEsUUFZQSxRQUFBLEdBQVcsRUFBRSxDQUFDLGFBQUgsQ0FBaUIsd0JBQWpCLENBWlgsQ0FBQTtBQUFBLFFBYUEsVUFBQSxHQUFhLEVBQUUsQ0FBQyxnQkFBSCxDQUFvQixrQ0FBcEIsQ0FiYixDQUFBO0FBY0EsYUFBQSxpREFBQTs4QkFBQTtBQUNFLFVBQUEsRUFBRSxDQUFDLEtBQUgsQ0FBQSxDQUFBLENBQUE7QUFBQSxVQUNBLEVBQUUsQ0FBQyxnQkFBSCxDQUFvQixPQUFwQixFQUE2Qix5QkFBN0IsQ0FEQSxDQURGO0FBQUEsU0FkQTtBQWtCQSxRQUFBLElBQW9CLFFBQXBCO0FBQUEsVUFBQSxRQUFRLENBQUMsS0FBVCxDQUFBLENBQUEsQ0FBQTtTQWxCQTtBQUFBLFFBcUJBLFlBQUEsQ0FBQSxDQXJCQSxDQUFBO0FBQUEsUUF3QkEsSUFBQSxHQUFPLEVBQUUsQ0FBQyxhQUFILENBQWlCLDZCQUFqQixDQXhCUCxDQUFBO0FBeUJBLFFBQUEsSUFBQSxDQUFBLElBQUE7QUFBQSxnQkFBQSxDQUFBO1NBekJBO0FBMEJBO0FBQUEsYUFBQSw2Q0FBQTt1QkFBQTtBQUNFLFVBQUEsRUFBQSxHQUFLLElBQUksQ0FBQyxhQUFMLENBQW9CLFNBQUEsR0FBUyxDQUFDLENBQUMsS0FBWCxHQUFpQixNQUFyQyxDQUFMLENBQUE7QUFBQSxVQUNBLGdCQUFBLENBQWlCLEVBQWpCLEVBQXFCLENBQUMsQ0FBQyxLQUF2QixDQURBLENBREY7QUFBQSxTQTFCQTtBQUFBLFFBK0JBLEdBQUEsR0FBTSxFQUFFLENBQUMsYUFBSCxDQUFpQixvQ0FBakIsQ0EvQk4sQ0FBQTtBQUFBLFFBZ0NBLGdCQUFBLENBQWlCLEdBQWpCLEVBQXNCLFVBQXRCLENBaENBLENBQUE7QUFBQSxRQW1DQSxJQUFBLEdBQU8sRUFBRSxDQUFDLGdCQUFILENBQW9CLHVEQUFwQixDQW5DUCxDQUFBO0FBb0NBO2FBQUEsNkNBQUE7eUJBQUE7QUFDRSx3QkFBQSxHQUFHLENBQUMsZ0JBQUosQ0FBcUIsT0FBckIsRUFBOEIseUJBQTlCLEVBQUEsQ0FERjtBQUFBO3dCQXZDRjtPQUFBLGNBQUE7QUEyQ0UsUUFESSxVQUNKLENBQUE7ZUFBQSxPQUFPLENBQUMsS0FBUixDQUFjLFNBQWQsRUFBeUIsQ0FBekIsRUEzQ0Y7T0FKSztJQUFBLENBQVA7R0F2SkYsQ0FBQTs7QUFBQSxFQXdNQSxNQUFNLENBQUMsT0FBUCxHQUFpQixRQXhNakIsQ0FBQTtBQUFBIgp9

//# sourceURL=/C:/Users/Administrator/.atom/packages/simplified-chinese-menu/tools/settings.coffee
