
## v0.2.1
* Update seti icon font.

## v0.1.0
* Use parts of seti icons.
