# atom-icons

The awesome icons for Atom.

![atom-icons](http://tvrcgo.qiniudn.com/github/atom-icons/preview.png)

## License
MIT
